<?php
    require_once('../php/sessionAdminC.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons"> 
	<link rel="stylesheet" href="../homestyle.css">
</head>
<body>
	
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="alog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	<nav class="navbar menu">
  		<div class="container-fluid">    
		<ul class="menu nav navbar-nav navbar">
		<li class="menu">
			<a href="adminHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="adminDept.php" class="menu">Departments</a>
		</li>
		<li class="menu">
			<a href="adminConsultants.php" class="menu">Consultants</a>
		</li>
		<li class="menu">
			<a href="adminPatient.php" class="menu">Patient Info</a>
		</li>
		<li class="menu">
			<a href="conSlot.php" class="menu">Slots</a>
		</li>
		<li class="menu">
			<a href="adminEmp.php" class="menu">Employees</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
	</ul>
	</div>
	</nav>

	<div class="container">
		<h1 class="display-3">Employees</h1>
		<hr>
		<div class="container-fluid" id="div_1">
			<h3 class="display-5">Add Attendant Account</h3>
			<hr>
			<div class="form-group">
			  <label for="fname">First Name:</label>
			  <input type="text" class="form-control" placeholder="First Name" id="fname">
			</div>
			<div class="form-group">
			  <label for="lname">Last Name:</label>
			  <input type="text" name="" placeholder="Last Name" id="lname"class="form-control">
			</div> 
			<div class="form-group">
			  <label for="dob">DOB</label>
			  <input type="date" name="" id="dob" class="form-control">
			</div>
			<label>Gender</label>
			<div class="well">
				<div class="form-check-inline">
				  <label class="form-check-label" for="radio1">
				    <input type="radio" class="form-check-input" ntype="radio" name="gender" value="Male" id="radio1">Male
				  </label>
				 </div>
				 <div class="form-check-inline">
				  <label class="form-check-label" for="radio2">
				    <input type="radio" class="form-check-input" ntype="radio" name="gender" value="Female" id="radio2">Female
				  </label>
				 </div>
				 <div class="form-check-inline">
				  <label class="form-check-label" for="radio3">
				    <input type="radio" class="form-check-input" ntype="radio" name="gender" value="Other" id="radio3">Other
				  </label>
				</div>
			</div>
			 <div class="form-group">
			  <label for="qdet">Qualification Details:</label>
			  <textarea class="form-control" rows="5" placeholder="Qualification Details" id="qdet"></textarea>
			</div> 
			<div class="form-group">
			  <label for="pno">Phone Number:</label>
			  <input type="text" name="" placeholder="Phone No." id="pno"class="form-control">
			</div> 
			<div class="form-group">
			  <label for="em">Email:</label>
			  <input type="text" name="" placeholder="Email" id="em"class="form-control">
			</div> 
			<div class="form-group">
			  <label for="add">Address:</label>
			  <textarea class="form-control" rows="5" placeholder="Full Address" id="add"></textarea>
			</div> 
			<br>
			<input type="button" name="" value="Add Attendant" onclick="addEmp()" class="btn btn-primary">
			<br>

			<div id="list1"></div>
			
			</div>



		<div class="container-fluid" id="div_2">

			<div>
			  <label>Attendant Id:</label>
			  <label id="l2" class="label label-primary"></label>
			</div>
			<div class="form-group">
			  <label for="pw">Attendant Password:</label>
			  <input type="password" class="form-control" id="pw" value="56789"> (Password: 56789)
			</div> 

			<input type="button" name="" value="Save" onclick="savePw()" class="btn btn-primary">
			<br>
			
		</div>
		<br><br>

		<div class="container-fluid">
				<div class="container" id="div_1">
				<h3 class="display-5">Add to slot</h3>
				<hr>
				<input type="button" name="" value="View All" onclick="viewList()" class="btn btn-primary">
				<br>
				<br>
				<label>Search: </label> <input type="text" name="" placeholder="Search" onkeyup="searchList()" id="name">
				<p id="info1"></p>
				<p id="info2"></p>
				<div id="div_3">
						
				</div>
				<div id="div_4">
						
				</div>
				<div id="div_5"><p id="d5p"></p></div>
				
				</div>
		</div>

<!-- 		<div id="div_1">
		<fieldset>
				<legend>Create Attendant Account</legend>   
				<br>
				
					First Name:  <input type="text" name="" placeholder="First Name" id="fname">     
				
					Last Name:  <input type="text" name="" placeholder="Last Name" id="lname">
				<br><br>
				
					DOB: <input type="date" name="" id="dob"> (mm/dd/yyyy)
				<br><br>
				
					Gender:

						<input type="radio" name="gender" value="Male"> Male
						<input type="radio" name="gender" value="Female"> Female
						<input type="radio" name="gender" value="Other">  Other
				<br><br>
				
					Qualification Details: <input type="text" name="" placeholder="Qualification Details" id="qdet">
				<br><br>
				
					Phone Number: <input type="text" name="" placeholder="Phone No." id="pno">     
				
					Email:  <input type="email" name="" placeholder="Email" id="em">
				<br><br>
				
					Address: <input type="text" name="" placeholder="Address" id="add">
				<br><br>
				
					<input type="button" name="" value="Add Attendant" onclick="addEmp()">

				<br><br>

					<label id="list1"></label>
				
			</fieldset>
		</div> -->
<!-- 		<div id="div_2">

			<fieldset>
				<br>
				Attendant Id: <label id="l2"></label>
				<br><br>
				Attendant Password: <input type="password" name="" id="pw" value="56789">  (Password: 56789)
				<br><br>
				<input type="button" name="" value="Save" onclick="savePw()">
				<br>
			</fieldset>


			
		</div>	 -->
		<!-- <div class="container-fluid">
			<h3 class="display-5">Add to Slot</h3>
			<hr>
			
				<br>
				<input type="button" name="" value="View All" onclick="viewList()">
				<label>Search: </label> <input type="text" name="" placeholder="Search" onkeyup="searchList()" id="name">
				<p id="info1"></p>
				<p id="info2"></p>
				<div id="div_3">
					
				</div>
				<div id="div_4">
					
				</div>
				<div id="div_5"><p id="d5p"></p></div>
			
		</div> -->	

	<script type="text/javascript">

		document.getElementById('div_2').style.display = 'none';

		function addEmp(){

			var fn = document.getElementById('fname').value;
			var ln = document.getElementById('lname').value;
			var dob = document.getElementById('dob').value;
			var q = document.getElementById('qdet').value;
			var pn = document.getElementById('pno').value;
			var em = document.getElementById('em').value;
			var a = document.getElementById('add').value;
			
			var radios = document.getElementsByName('gender');

			for (var i = 0, length = radios.length; i < length; i++) {
			  if (radios[i].checked) {
			    var g = radios[i].value;
			    break;
			  }
			}

			//document.getElementById('list1').innerHTML = fn+' '+ln+' '+dob+' '+q+' '+pn+' '+em+' '+g+' ';

			if ((fn=='')||(ln=='')||(dob=='')||(q=='')||(pn=='')||(em=='')||(g=='')) {
				document.getElementById('list1').innerHTML= "Empty input field!";
			}else{

				//document.getElementById('list1').innerHTML = fn+' '+ln+' '+dob+' '+q+' '+pn+' '+em+' '+g+' ';

				var xhttp = new XMLHttpRequest();
			 	xhttp.open('POST', '../php/adminEmpC.php', true);
				xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp.send('addemp='+'true'+'&fn='+fn+'&ln='+ln+'&dob='+dob+'&q='+q+'&pn='+pn+'&em='+em+'&g='+g+'&a='+a);
				
				xhttp.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){

						if ((this.responseText=='operation failed')||(this.responseText=='empty')) {

							
							document.getElementById('list1').innerHTML = this.responseText;

						}else{

							document.getElementById('div_2').style.display = 'block';

							document.getElementById('div_1').style.display = 'none';

							document.getElementById('l2').innerHTML = this.responseText;
																				

						}

													

					}
				}
			}	

		}



		function viewList(){

			//var n = document.getElementById('name').value;

			document.getElementById('info2').innerHTML ="";
			document.getElementById('div_4').innerHTML ="";

				var xhttp2 = new XMLHttpRequest();
			 	xhttp2.open('POST', '../php/adminEmpC.php', true);
				xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp2.send('emplist='+'true');
				
				xhttp2.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
						document.getElementById('div_3').innerHTML = this.responseText;

					}
				}

		}

		function searchList(){
			document.getElementById('info2').innerHTML = "";
			document.getElementById('div_4').innerHTML ="";
			document.getElementById('info1').style.display = 'none';
			document.getElementById('div_3').style.display = 'block';
			if (document.getElementById('div_5').style.display=='block') {
				document.getElementById('div_5').style.display='none';
			}
			if(document.getElementById('info2').style.display=='block') {
				document.getElementById('info2').style.display='none';
			}


			var n = document.getElementById('name').value;

				var xhttp3 = new XMLHttpRequest();
			 	xhttp3.open('POST', '../php/adminEmpC.php', true);
				xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp3.send('searchlist='+'true'+'&n='+n);
				
				xhttp3.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
						document.getElementById('div_3').innerHTML = this.responseText;

					}
				}

		}

		function addSlot(aid, aname){

			document.getElementById('info2').innerHTML = "<label>Id: </label><label id=\"a_id\">"+aid+"</label><br>"+"<label>Name: </label>"+aname;




			var a = aid;

			var xhttp4 = new XMLHttpRequest();
			 	xhttp4.open('POST', '../php/adminEmpC.php', true);
				xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp4.send('addslot='+'true'+'&a='+a);
				
				xhttp4.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
						document.getElementById('div_3').innerHTML = this.responseText;
					}
				}
		}

		function slotInfo(){

			var sid = document.getElementById('slot_search').value;

			var xhttp5 = new XMLHttpRequest();
			 	xhttp5.open('POST', '../php/adminEmpC.php', true);
				xhttp5.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp5.send('slotinfo='+'true'+'&sid='+sid);
				
				xhttp5.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
						document.getElementById('div_4').innerHTML = this.responseText;
					}
				}

		}

		function addToSlot(s){

			var aid = document.getElementById('a_id').innerHTML;
			var sid  =  s;

			var xhttp6 = new XMLHttpRequest();
			 	xhttp6.open('POST', '../php/adminEmpC.php', true);
				xhttp6.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp6.send('attslot='+'true'+'&aid='+aid+'&sid='+sid);
				
				xhttp6.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
						document.getElementById('div_4').innerHTML = this.responseText;
					}
				}

		}

		function viewSlot(atid, sid){

			document.getElementById('info2').style.display = 'block';

			document.getElementById('info2').innerHTML = "<label>Id: </label><label id=\"a_id\">"+atid+"</label><br>"+"<label>Name: </label>"+sid;

			var xhttp7 = new XMLHttpRequest();
			 	xhttp7.open('POST', '../php/adminEmpC.php', true);
				xhttp7.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp7.send('viewslotlist='+'true'+'&attid='+atid);
				
				xhttp7.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
						document.getElementById('div_3').style.display = 'none';
						document.getElementById('div_5').style.display = 'block';
						document.getElementById('div_5').innerHTML = this.responseText; 
					}
				}




		}

		function savePw(){

			var apid = document.getElementById('l2').innerHTML;
			var pw = document.getElementById('pw').value;

			var xhttp8 = new XMLHttpRequest();
			 	xhttp8.open('POST', '../php/adminEmpC.php', true);
				xhttp8.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp8.send('savep='+'true'+'&auid='+apid+'&pw='+pw);
				
				xhttp8.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){

						document.getElementById('div_2').innerHTML = this.responseText;
						//document.getElementById('div_3').style.display = 'none';
						//document.getElementById('div_5').innerHTML = this.responseText; 
					}
				}
			
		}

		function deleteFromSlot(s, a){

			var slotid = s;
			var attid = a;

			var xhttp9 = new XMLHttpRequest();
			 	xhttp9.open('POST', '../php/adminEmpC.php', true);
				xhttp9.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp9.send('remove_a='+'true'+'&slid='+slotid+'&attid='+attid);
				
				xhttp9.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){
						document.getElementById('div_5').style.display = 'none';
						document.getElementById('info1').innerHTML=this.responseText;
					}
				}

		}
		



	</script>

	


</body>
</html>