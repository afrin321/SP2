<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="homestyle.css">
</head>
<body>
	<div class="container-fluid">
	
	
	



<div class="container-fluid">
		<ul class="up">
<!-- 		<li class="up">
			<a href="views/Patient/patientLogin.php" class="up">Log In</a>
		</li>
		<li class="up">
			<a href="views/Patient/patientRegister.php" class="up">Register</a>
		</li> -->
		<li class="left"><img src="logo.png" class="img-fluid" class="left"></li>
		<li class="up"><a href="views/Patient/patientLogin.php" class="up"><span class="glyphicon glyphicon-user"></span>Login</a></li>
		<li class="up"><a href="views/Patient/patientRegister.php" class="up"><span class="glyphicon glyphicon-log-in"></span>Register</a></li>
	</ul>
</div>
	<br>
	<nav class="navbar">
  	<div class="container-fluid">
    
		<ul class="menu nav navbar-nav">
			<li class="menu">
				<a href="" class="menu"><i class="material-icons">home</i>  Home</a>
			</li>
			<li class="menu">
				<a href="" class="menu">About Us</a>
			</li>
			<li class="menu">
				<a href="" class="menu">Consultants</a>
			</li>
			<li class="menu">
				<a href="views/appointment.php" class="menu">Appointment</a>
			</li>
			<li class="menu">
				<a href="" class="menu">Services</a>
			</li>
			<li class="menu">
				<a href="" class="menu">Contact Us</a>
			</li>			
		</ul>
		
		
	</div>
	</nav>	
	<br>

	<div class="container sec_d" >
		<br>
		<div class="container">
			<br><br>
		  <div class="jumbotron txt">
		    <h1>Welcome to ApSys</h1>
		    <p>Here we provide the best services for wave scheduling appontments. 
		    	<h2>Join us Today!</h2></p>

		    <button type="button" class="btn btn-primary btn-lg htt">View Appointments</button>

		    <button type="button" class="btn btn-primary btn-lg htt">Login</button>
		    <br><br>

		  </div>
		  <br>
		</div>	
	</div>
	


<!-- 	<div class="sec_d container-fluid">>
		<label class="sec_d"><b> Welcome to ApSys Clinic </b></label>
		<br>
		<br>
		<br>
		<br>
		<p>Lorem</p>
	</div> -->
	
	

	

	





	
	<br>
	<div class="footer">
		<div>
			<table>
				<tr>
					<td class="footer">
						<img src="">
						
					</td>
					<td class="footer">
						<h2 align="left">Employee Login</h2>
						<hr>
						<br>
						<a href="../New folder/views/login.php">Admin</a><br><br>
						<a href="../New folder/views/Consultant/consLogin.php">Consultant</a><br><br>
						<a href="../New folder/views/Attendant/attLogin.php">Attendee</a><br><br>


					</td>
				</tr>
			</table>
			<div>
				<h4 align="center">Copyright@2021</h4>
			</div>

		</div>
	</div>
		
	

	

</body>
</html>