<!DOCTYPE html>
<html>
<head>
	<title>Appointments</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../homestyle.css">
</head>
<body onload="loadItems()">
	<div class="container-fluid">

	<div class="container-fluid">
		<ul class="up">

			<li class="left"><img src="logo.png" class="img-fluid" class="left"></li>
			<li class="up"><a href="Patient/patientLogin.php" class="up"><span class="glyphicon glyphicon-user"></span>Login</a></li>
			<li class="up"><a href="Patient/patientRegister.php" class="up"><span class="glyphicon glyphicon-log-in"></span>Register</a></li>
		</ul>
	</div>
	<br>
	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="../index.php" class="menu">Home</a>
				</li>
				<li class="menu">
					<a href="" class="menu">About Us</a>
				</li>
				<li class="menu">
					<a href="" class="menu">Departments</a>
				</li>
				<li class="menu">
					<a href="" class="menu">Consultants</a>
				</li>
				<li class="menu">
					<a href="appointment.php" class="menu">Appointment</a>
				</li>
				<li class="menu">
					<a href="" class="menu">Services</a>
				</li>
				<li class="menu">
					<a href="contact.php" class="menu">Contact Us</a>
				</li>
			</ul>
		</div>
	</nav>
	<div class="container">
		<h1 class="display-3">Select Appointment</h1>
		<hr>

<!-- 		<label>Department:  </label> 

		<select id="forDept" onchange="getDetail()">
			<ul>
				<li><option value="no">Not selected</option></li>
			</ul>
			
		</select> -->

		<div class="well">

			<div class="form-group">
			  <label for="forDept">Select Department:</label>
			  <select class="form-control" id="forDept" onchange="getDetail()">
			  </select>
			</div> 

			<br>

			<div class="form-group">
			  <label for="forCons">Select Consultant:</label>
			  <select class="form-control" id="forCons" onchange="getConDetail()">
			  </select>
			</div> 

		</div>
		

<!-- 		<label>Consultant: </label>

		<select id="forCons" onchange="getConDetail()">
			<ul>
				<option value="no">Not selected</option></li>
			</ul>
		</select> -->

		<p id="see"></p>

		

		<div id="res" class="container">
			
		</div>
		
	</div>

	
<!-- 
	<div>

		<h1>Select Consultant below:</h1>

		<fieldset>


		<label>Department:  </label> 

		<select id="forDept" onchange="getDetail()">
			<ul>
				<li><option value="no">Not selected</option></li>
			</ul>
			
		</select>

		<br>
		<br>
		

		<label>Consultant: </label>

		<select id="forCons" onchange="getConDetail()">
			<ul>
				<option value="no">Not selected</option></li>
			</ul>
		</select>

		<br>
		<br>

		Search For Consultant: <input type="text" name="" placeholder="Consultant Name">

	</fieldset>

		<p id="see"></p>

		

		<div id="res">
			
		</div>
	

	</div> -->
</div>

	<script type="text/javascript">

		function loadItems(){
			showDept();
			getCons();
		}

		function showDept(){

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../php/appointmentHomeC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('dept=true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('forDept').innerHTML = this.responseText;
				}
			}
		}

		function getCons(){

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../php/appointmentHomeC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('allcon=true');

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('forCons').innerHTML = this.responseText;
				}
			}



		}

		function showCons(){

			var dept = document.getElementById('forDept').value;
			//document.getElementById('see').innerHTML = dept;

			if (dept!=null) {

				var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../php/appointmentHomeC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('all=true&depart='+dept);

			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('forCons').innerHTML = this.responseText;
				}
			}


			}else{
				getCons();
			}		
			
			
		}

		function forDeptInfo(){
			getDetail();
		}

		function getDetail(){

			var d = document.getElementById('forDept').value;
			//document.getElementById('res').innerHTML = d;

			if (d!= 'no') {

			var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../php/appointmentHomeC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('conbydept='+d);

			xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res').innerHTML = this.responseText;
				}
			}
		}


			
		}

		function getConDetail(){

			var id = document.getElementById('forCons').value;

			if (id!='no') {

			var xhttp5 = new XMLHttpRequest();
		 	xhttp5.open('POST', '../php/appointmentHomeC.php', true);
			xhttp5.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp5.send('conbyid='+id);

			xhttp5.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res').innerHTML = this.responseText;
				}
			}

		}





		}

		function getAppointmentList(slot_id){


			var xhttp6 = new XMLHttpRequest();
		 	xhttp6.open('POST', '../php/appointmentHomeC.php', true);
			xhttp6.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp6.send('app_list='+slot_id);

			xhttp6.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res').innerHTML = this.responseText;
				}
			}


		}

		function makeAppointment(id, sid){

			var d1 = document.getElementById('date'+id).innerHTML;
			var d2 = document.getElementById('day'+id).innerHTML; 

			//document.getElementById('res').innerHTML = d1+' '+d2+' '+sid;

			var xhttp7 = new XMLHttpRequest();
		 	xhttp7.open('POST', '../php/appointmentC.php', true);
			xhttp7.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp7.send('make_app='+'true'+'&date='+d1+'&sid='+sid);

			xhttp7.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					//document.getElementById('res').innerHTML = this.responseText;

					if (this.responseText=='true') {
						
						window.location.assign("Patient/patientPayment.php");
					}else{
						window.location.assign("Patient/patientLogin.php");
					}
				}
			}

			

		}

		



		


	</script>



	

</body>
</html>