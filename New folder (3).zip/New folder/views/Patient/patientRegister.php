<!DOCTYPE html>
<html>
<head>
	<title>Patient Registration Portal</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="patientLoginStyle.css">
	
</head>
<body>
	<div class="container-fluid">
		<div class="container" id="div1">
			<div class="panel panel-success">
			    <div class="panel-heading"><h1>Patient Registration</h1></div>
				    <div class="panel-body">
				    	<div class="container" id="inf"></div>
				    	<div class="form-group">
						  <label for="pfname">First Name:</label>
						  <input type="text" class="form-control" id="pfname">
						</div>
						<div class="form-group">
						  <label for="psname">Last Name:</label>
						  <input type="text" class="form-control" id="psname">
						</div> 
						<div class="form-group">
						  <label for="pemail">Email:</label>
						  <input type="email" class="form-control" id="pemail">
						</div> 
						<div class="form-group">
						  <label for="pphone">Phone No.:</label>
						  <input type="text" class="form-control" id="pphone">
						</div> 
						<div class="form-group">
						  <label for="pzcode">Zip Code:</label>
						  <input type="text" class="form-control" id="pzcode">
						</div> 
						<div class="form-group">
						  <label for="ppw">Password:</label>
						  <input type="password" class="form-control" id="ppw">
						</div> 
						<div class="form-group">
						  <label for="pdate">Date:</label>
						  <input type="date" class="form-control" id="pdate">
						</div> 
						<div class="form-group">
						  <label for="pcity">Select city:</label>
						  <select class="form-control" id="pcity">
						    <option value=""></option><option value="Dhaka">Dhaka</option>
						    <option value="Chittagong">Chittagong</option>
						    <option value="Khulna">Khulna</option>
						    <option value="Barisal">Barisal</option>
						    <option value="Sylhet">Sylhet</option><option value="Rajshahi">Rajshahi</option><option value="">Rangamati</option>
						  </select>
						</div> 
						<div class="container">
						<label>Select gender:</label>	
						  <form>
						    <label class="radio-inline">
						      <input type="radio" name="gender" value="male">Male
						    </label>
						    <label class="radio-inline">
						      <input type="radio" name="gender" value="female">Female
						    </label>
						    <label class="radio-inline">
						      <input type="radio" name="gender" value="other">Other
						    </label>
						  </form>
						</div>
						<div class="form-group">
						  <label for="padd">Adress:</label>
						  <textarea class="form-control" rows="5" id="padd"></textarea>
						</div> 
						<input type="button" name="" value="Register" class="btn btn-success" onclick="register()">
						<input type="reset" name="" value="Reset" class="btn btn-success">

				</div>
		    </div>
		</div>		
	</div>
	
		<!-- <div class="title1"><h1>   Patient Portal</h1></div>

		<hr> -->
		<!-- <div class="div1" id="div1">
		<br>
		<fieldset>
			<div class="title2"><h1>    Registration</h1></div>
		<form method="post">

			<table>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>First Name</label></td>
					<td></td>
					<td><label>Sur Name</label><br></td>
					<td></td>
				</tr>
				<tr>
					<td><label><input type="text" name="" placeholder="First name" id="pfname"><br></label></td>
					<td></td>
					<td><label><input type="text" name="" placeholder="Sur name" id="psname"></label><br></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>Email Address</label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label><input type="email" name="" placeholder="Email Address" id="pemail"></label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>Phone Number</label></td>
					<td></td>
					<td><label>Zip Code</label></td>
					<td></td>
				</tr>
				<tr>
					<td><label><input type="text" name="" placeholder="Phone No."  id="pphone"></label></td>
					<td></td>
					<td><label><input type="text" name="" placeholder="Zip Code" id="pzcode"></label></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>Password</label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label><input type="password" name="" placeholder="Password" id="ppw"></label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>Date of Birth</label></td>
					<td></td>
					<td><label>City</label></td>
					<td></td>
				</tr>
				<tr>
					<td><label><input type="date" name="" id="pdate"></label> (mm/dd/yyyy) </td>
					<td></td>
					<td><label><select placeholder="City" id="pcity"><ul><option value=""></option><option value="Dhaka">Dhaka</option><option value="Chittagong">Chittagong</option><option value="Khulna">Khulna</option><option value="Barisal">Barisal</option><option value="Sylhet">Sylhet</option><option value="Rajshahi">Rajshahi</option><option value="">Rangamati</option></ul></select></label></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>Gender</label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label><input type="radio" name="gender" value="male" > Male  <input type="radio" name="gender" value="female" > Female  <input type="radio" name="gender" value="other"> Other</label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>Address</label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label><textarea name="" placeholder="Address" rows="4" cols="35" id="padd"></textarea></label></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td><label>Already have an account?  <a href="#">Login here.</a></label></td>
					<td>				
					</td>
					<td id="res"></td>
					<td><label><input type="button" name="" value="Register" class="button1" onclick="register()"></label><label><input type="reset" name="" value="Reset" class="button1"></label></td>
				</tr>


			</table>
			
			
			
			


		</form>
	</fieldset>
	</div> -->
	<div  id="div2" class="container-fluid">
		<div class="container">
			<div class="panel panel-success">
		      <div class="panel-heading">Patient Login Details</div>
		      <div class="panel-body">
		      		<label>Patient Id:</label><label id="pid"></label>
					<br>
					<br>
					<label>Password:</label><label id="passw"></label>
					<input type="button" name="" value="Login" class="btn btn-success" onclick="login()">
		  	  </div>
		    </div>
		</div>
<!-- 		<fieldset>
			<h1>Patient Login Details</h1>
			<h3>Account successfully created. Please save login details.</h3>
			<br>
			<br>
			<label>Patient Id:</label><label id="pid"></label>
			<br>
			<br>
			<label>Password:</label><label id="passw"></label>
			<br>
			<br>
			<label><input type="button" name="" value="Login" class="button1" onclick="login()"></label>
		</fieldset> -->
	</div>
	<div>
		<br>
			<br>
		<p align="center"><span color="white">
			


		Copyright@2021</span>


	</p>
	</div>
	<script type="text/javascript">
		document.getElementById('div2').style.display = "none";
		//<link rel="stylesheet" href="patientLoginStyle.css">

		function validate(){
			
		}

		function register(){

			var fname = document.getElementById('pfname').value;
		    var sname = document.getElementById('psname').value;
		    var email = document.getElementById('pemail').value; 
		    var phone = document.getElementById('pphone').value;
		    var pw = document.getElementById('ppw').value;
		    var zip = document.getElementById('pzcode').value;
		    var city = document.getElementById('pcity').value;
		    var add = document.getElementById('padd').value;
		    var dob = document.getElementById('pdate').value;
		    var gen;

		    var ele = document.getElementsByName('gender'); 
              
            for(i = 0; i < ele.length; i++) { 
                if(ele[i].checked) 
                gen = ele[i].value; 
            }

            if (fname==''||sname==''||email==''||phone==''||pw==''||zip==''||city==''||add==''||dob==''||gen=='') {

            	document.getElementById('inf').innerHTML = "<div class=\"alert alert-warning\"><strong>Empty Entry!</strong> Input fields are empty.</div>";

            }else{

            	var xhttp = new XMLHttpRequest();
			 	xhttp.open('POST', '../../php/patientRegisterC.php', true);
				xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp.send('reg='+'true'+'&fname='+fname+'&sname='+sname+'&email='+email+'&phone='+phone+'&pw='+pw+'&zip='+zip+'&city='+city+'&add='+add+'&dob='+dob+'&gen='+gen);

	         	xhttp.onreadystatechange = function(){
					if(this.readyState == 4 && this.status == 200){

						if (this.responseText!="Unexpected error. Try again later" || this.responseText!="error") {
							document.getElementById('div1').style.display = "none";
							document.getElementById('div2').style.display = "block";
							document.getElementById('pid').innerHTML = this.responseText;
							document.getElementById('passw').innerHTML = pw;
						}else{

						document.getElementById('res').innerHTML = this.responseText;

					}

											
					}
				}

            }




		}

		function login(){
			window.location.assign("patientLogin.php");
		}
	</script>
	

</body>
</html>