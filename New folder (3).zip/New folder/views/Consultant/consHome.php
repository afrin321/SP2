<?php

    require_once('../../php/sessionConsC.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title>Consultant Home</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../../homestyle.css">
</head>
<body onload="getAll()">
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="clog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="consHome.php" class="menu">Home</a>
				</li>
				<li class="menu">
					<a href="conApp.php.php" class="menu">Appointments</a>
				</li>
				<li class="menu">
					<a href="conCancel.php" class="menu">Cancellations</a>
				</li>
				<li class="menu">
					<a href="conQueue.php" class="menu">Queues</a>
				</li>		
				<li class="menu">
					<a href="#" class="menu">Settings</a>
				</li>
			</ul>
		</div>
	</nav>
	<br><br>
	<div class="container">
		<h1 class="display-5">Today's Appointments</h1>
		<hr>
		<br>
		<div id="res1" class="container">
		
		</div>
		<p id="stat1"></p>
	</div>
<!-- 	<h2>Today's Appointments</h2>

	<div id="res1">
		
	</div>
	<p id="stat1"></p> -->

	<script type="text/javascript">
		function getAll(){
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/conHomeC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('gettoday='+'true');	
		
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=='error') {
						document.getElementById('res1').innerHTML = "No Appointments for this day";
					}else{
						document.getElementById('res1').innerHTML = this.responseText;
					}

					
					
				}
			}
		}

		function openQ(s){
			

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/conHomeC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('setqinfo='+s);	
		
			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					/*if (this.responseText=='true') {
						location.replace("conQueue.php?error=no");
					}else{
						document.getElementById('stat1').innerHTML = "There was some error. Try again later.";
					}*/

					location.replace("conQueue.php");
					
				}
			}

		}
		
	</script>

	


</body>
</html>