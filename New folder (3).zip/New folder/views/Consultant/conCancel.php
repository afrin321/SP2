<?php

    require_once('../../php/sessionConsC.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title>Consultation Cancellations</title>
		<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../../homestyle.css">
</head>
<body>
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="clog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="consHome.php" class="menu">Home</a>
				</li>
				<li class="menu">
					<a href="conApp.php.php" class="menu">Appointments</a>
				</li>
				<li class="menu">
					<a href="conCancel.php" class="menu">Cancellations</a>
				</li>
				<li class="menu">
					<a href="conQueue.php" class="menu">Queues</a>
				</li>		
				<li class="menu">
					<a href="#" class="menu">Settings</a>
				</li>
			</ul>
		</div>
	</nav>
	<div class="container">
		<h1 class="display-5">Cancellations</h1>
		<hr>
		<br>
		<div class="container" id="res"></div>
		<label>Cancelation Date: </label> <input type="date" id="d"> <input type="button" onclick="getC()" value="Open" class="btn btn-primary">

		<div id="upc" class="container">
			
		</div>



		
	</div>
	

	<script type="text/javascript">	

		function getC() {

			var d = document.getElementById('d').value;

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/cancelAppC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('cancelex='+'true'+'&d='+d);

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('upc').innerHTML= this.responseText;

									
				}
			}

		}

		function cancelqueue(q, s, d){

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/cancelAppC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('q='+q+'&s='+s+'&d='+d);

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					
					if (this.responseText.trim()=='true') {
						document.getElementById('res').innerHTML = "<div class=\"alert alert-success\">  <strong>Success!</strong> Appointment deleted successfully.</div>";

					}else{
						document.getElementById('res').innerHTML = "<div class=\"alert alert-danger\">  <strong>Danger!</strong> Appointment cannot be deleted.</div>";
					}

					

									
				}
			}
			
		}


		
		
	</script>

	


</body>
</html>