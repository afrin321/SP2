<?php
    require_once('../../php/sessionConsC.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Consultant Queue</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<meta charset="utf-8">
  		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../../homestyle.css">
</head>
<body onload="loadInitial()">
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="clog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="consHome.php" class="menu">Home</a>
				</li>
				<li class="menu">
					<a href="conApp.php.php" class="menu">Appointments</a>
				</li>
				<li class="menu">
					<a href="#" class="menu">Cancellations</a>
				</li>
				<li class="menu">
					<a href="conQueue.php" class="menu">Queues</a>
				</li>		
				<li class="menu">
					<a href="#" class="menu">Settings</a>
				</li>
			</ul>
		</div>
	</nav>
	<div class="container">
		<h1 class="display-5">Today's Appointments</h1>
		<hr>
		<br>
			<div id="res1" class="container-fluid">
		
			</div>
			<div id="res3" class="container-fluid"></div>
			<p id="stat1"></p>
		
	</div>

<!-- 	<div id="res1">
		
	</div>
	<div id="res3"></div>
	<p id="stat1"></p>
 -->
	<script type="text/javascript">
		function loadInitial(){
			setInterval(getAll,10000);
		}

		function getAll(){
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/conQueueC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('allq='+'true');	
		
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res1').innerHTML = this.responseText;
					
				}
			}
		}

		function updateList(q){

			var s = document.getElementById('dstat').value;
			var l = document.getElementById('lp').value;
			//document.getElementById('res3').innerHTML = s+" "+l+" ";
			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/conQueueC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('upd='+'true'+'&s='+s+'&l='+l+'&q='+q);	
		
			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res2').innerHTML = this.responseText;
					
				}
			}
		}

		function callP(p, a, pid){

			var pqid = p;
			var appid = a;
			var pd = pid;

			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/conQueueC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('calltojoin='+'true'+'&pid='+pqid+'&appid='+appid+'&p='+pd);	
		
			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('stat1').innerHTML = this.responseText;
					
				}
			}

		}

		function joinP(p, a, pid){

			var pqid = p;
			var appid = a;
			var pd = pid;

			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/conQueueC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('joined='+'true'+'&pid='+pqid+'&appid='+appid+'&p='+pd);	
		
			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('stat1').innerHTML = this.responseText;
					
				}
			}

		}

		function markP(p, a, pid){

			var pqid = p;
			var appid = a;
			var pd = pid;

			var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../../php/conQueueC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('mark='+'true'+'&pid='+pqid+'&appid='+appid+'&p='+pd);	
		
			xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('stat1').innerHTML = this.responseText;
					
				}
			}

		}

		
		
	</script>

	


</body>
</html>