<?php
    require_once('../php/sessionAdminC.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>  
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../homestyle.css">
</head>
<body>


	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="alog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>

	
	
		<nav class="navbar menu">
  		<div class="container-fluid">    
		<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="adminHome.php" class="menu">Home</a>
				</li>
				<li class="menu">
					<a href="adminDept.php" class="menu">Departments</a>
				</li>
				<li class="menu">
					<a href="adminConsultants.php" class="menu">Consultants</a>
				</li>
				<li class="menu">
					<a href="adminPatient.php" class="menu">Patient Info</a>
				</li>
				<li class="menu">
					<a href="conSlot.php" class="menu">Slots</a>
				</li>
				<li class="menu">
					<a href="adminEmp.php" class="menu">Employees</a>
				</li>
				<li class="menu">
					<a href="adminEmp.php" class="menu">Settings</a>
				</li>
			</ul>
		</div>
		</nav>
		<br>
		<div class="container">
		  <div class="jumbotron">
		    <h1>Admin Home</h1>
		    <p>Use the navigation bar above to explore the website.</p>
		  </div>
		  <br>
		</div>



		






	


</body>
</html>