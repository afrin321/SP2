<?php

    require_once('../../php/sessionAttC.php');

?>
<!DOCTYPE html>
<html>
<head>
	<title>Attendant Queue</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="../../homestyle.css">
</head>
<body onload="loadInitial()">
	<div class="container-fluid">
		<ul class="up">
			<li class="left"><img src="../../logo.png" class="img-fluid" class="left"></li>
			<li class="up">
				<form action="../../php/loginC.php" method="post">
					<input type="submit" class="btn btn-primary logout" name="attlog" value="Logout">
				</form>
			</li>			
		</ul>
	</div>
	<nav class="navbar menu">
  		<div class="container-fluid">    
			<ul class="menu nav navbar-nav">
				<li class="menu">
					<a href="attHome.php" class="menu">Home</a>
				</li>
				<li class="menu">
					<a href="conApp.php.php" class="menu">Schedule</a>
				</li>
				<li class="menu">
					<a href="attQueue.php" class="menu">Queues</a>
				</li>		
				<li class="menu">
					<a href="#" class="menu">Settings</a>
				</li>
			</ul>
		</div>
	</nav>

	<div class="container">
		<h1 class="display-5">Today's Appointments</h1>
		<hr>
		<br>	
		<div id="res1">
		
		</div>
		<div id="res3" class="container"></div>
		<p id="stat1"></p>
	</div>

<!-- 	<div id="res1">
		
	</div>
	<div id="res3"></div>
	<p id="stat1"></p> -->

	<script type="text/javascript">
		//var e=1;

		function loadInitial(){
			setInterval(getAll,3000);
		}
		
		function getAll(){
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/attQueueC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('allq='+'true');	
		
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res1').innerHTML = this.responseText;
					
					//console.log(e);
					//e+=1;
					
				}
			}
		}

		function updateList(q){

			var s = document.getElementById('dstat').value;
			var l = document.getElementById('lp').value;
			//document.getElementById('res3').innerHTML = s+" "+l+" ";
			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/conQueueC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('upd='+'true'+'&s='+s+'&l='+l+'&q='+q);	
		
			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res2').innerHTML = this.responseText;
					
				}
			}
		}

		function arrivedUp(p,a){
			var pid = p;
			var appid = a;

			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/attQueueC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('arrived='+'true'+'&a='+appid+'&p='+pid);	
		
			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('arrival_stat').innerHTML = this.responseText;
					
				}
			}


		}

		function updateNext(p,q){

			var pq = p;
			var qid = q;

			var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../../php/attQueueC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('upnext='+'true'+'&q='+qid+'&p='+pq);	
		
			/*xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('up_next').innerHTML = this.responseText;
					
				}
			}*/

		}

		function undoNext(p, q){

			var pq = p;
			var qid = q;

			var xhttp5 = new XMLHttpRequest();
		 	xhttp5.open('POST', '../../php/attQueueC.php', true);
			xhttp5.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp5.send('undonext='+'true'+'&q='+qid+'&p='+pq);

		}

		
		
	</script>

	


</body>
</html>