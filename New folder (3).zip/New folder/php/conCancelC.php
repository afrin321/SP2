<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['upcoming'])) {

		$data = $_COOKIE['cons_id'];
		
		$x =  upcomingAppForCon($data);

		if ($x) {

			echo "<div class=\"table-responsive\"><table class=\"table\">
						<tr>
							<th>Slot Id</th><th>Date</th><th>Day</th><th>On Queue</th><th>Unpaid</th><th>More Options</th></tr>";

							if(count($x)>5){
								$st = 4;
							}else{
								$st = count($x);
							}



			for ($j=0; $j < $st ; $j++){

				echo "<tr>";
				echo "<td>";
				echo $x[$j]['slot_id'];
				echo "</td><td>";
				echo $x[$j]['queueDate'];
				echo "</td><td>";
				echo ucfirst($x[$j]['slot_day']);
				echo "</td><td>";
				echo $x[$j]['queueCurQuantity'];
				echo "</td><td>";
				echo countWaitQueue($x[$j]['queueId']);
				echo "</td><td>";

				if ($x[$j]['queueCurQuantity']>0) {
					
					echo "<a href=\"#\" onclick=\"openQueue(".$x[$j]['queueId'].")\">Open Queue</a>"."	|	"."<a href=\"cancelQueue(".$x[$j]['queueId'].")\">Cancel</a>";
				}else{

					echo "<a href=\"#\">Cancel</a>";

				}
				
				echo "</td></tr>";
			}

			echo "</table></div>";
			
		}else{

			echo "There are no upcoming appointments. Slots may not be set.";
		}
	}

	if (isset($_POST['setqinfo'])) {

		$id = $_POST['setqinfo'];
		
		setcookie("qidforcon", $id, time()+600, "/");

		if (isset($_COOKIE['qidforcon'])) {
			echo "true";
		}else{
			echo "false";
		}
	}






?>