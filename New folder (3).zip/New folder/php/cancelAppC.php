<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['cancelex'])){

		$data=[
			'd'=>$_POST['d'],
			'c'=>$_COOKIE['cons_id']
		];

		$x = getSlotForCancel($data);

		if ($x) {
			echo "<br>";
			echo "<div class=\"table-responsive\">
  					<table class=\"table\">";
  			echo "<tr><th>Date</th><th>Day</th><th>Time</th><th>Enrolled</th><th>Cancel</th></tr>";
  			for ($i=0; $i <count($x) ; $i++) { 
  				
  				echo "<tr><td>".$x[$i]['queueDate']."</td><td>".ucfirst($x[$i]['slot_day'])."</td><td>".date("g:i a", strtotime($x[$i]['slot_start_time']))." - ".date("g:i a", strtotime($x[$i]['slot_end_time']))."</td><td>".$x[$i]['queueCurQuantity']."</td><td><button type=\"button\" class=\"btn btn-danger\" onclick=\"cancelqueue(".$x[$i]['queueId'].",".$x[$i]['queueSlotId'].",".$x[$i]['queueDate'].")\">Cancel</button></td></tr>";
  			}
  			echo "</table></div>";
		}else{
			echo "<br>You do not have any appointments on this day.";
		}
		
	}

	if (isset($_POST['q'])) {
		$z = listForCancel($_POST['q']);

		if ($z) {
			if ($z>0) {

				for ($i=0; $i <count($z) ; $i++) { 
					$data = [
						'p'=>$z[$i]['pid'],
						's'=>$_POST['s']
					];
					$a = updateAccPay($data);
					$m = "Dear valued Client, your Appointment on ".$x[$i]['queueDate']." has been cancelled. Your payment has been refunded.	
										- Hospital Management";
					$title = "Cancelled Appointment";
					$d3 = [
						'p'=>$z[$i]['pid'],
						'm'=>$m,
						't'=>$_POST['d'],
						'title'=>$title
					];
					$v = notificationOne($d3);
					$w = updateAppQueueOnCancel($_POST['q']);

				}
				$u = updateCancelbyCon($_POST['q']);

				if ($u) {
					echo "true";
				}else{
					echo "false";
				}
				
			}else{

				$u = updateCancelbyCon($_POST['q']);

				if ($u) {
					echo "true";
				}else{
					echo "false";
				}

			}

		}else{

			$u = updateCancelbyCon($_POST['q']);

				if ($u) {
					echo "true";
				}else{
					echo "false";
				}

		}
	}
	





?>