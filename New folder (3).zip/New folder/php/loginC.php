<?php
	session_start();

	require_once('../service/userService.php');

	if(isset($_POST['submit'])){

		$uid = $_POST['uid'];
		$pw = $_POST['pw'];


		if(empty($uid) || empty($pw)){
			echo "empty";
			//header('location: ../views/login.php?error=null');
		}else{

			$user = [
				'uid'=>$uid,
				'pw'=>$pw
			];

			$status = validate($user);

			

			if($status){
				setcookie('uid', $_POST['uid'], time() + (3600*2), "/");
				    				
					echo "Successfully found.";
					//header('location: ../views/adminHome.php?error=no');

			}
			else{
				//header('location: ../views/login.php?error=invalid');
				echo "Invalid entry. Account does not exist.";
				//header('location: ../views/adminHome.php?error=no');
			}
		}
		
	}

	if (isset($_POST['plogin'])) {

		if (isset($_POST['pid']) && isset($_POST['ppw'])) {
			$data = [
				'pid'=>$_POST['pid'],
				'ppw'=>$_POST['ppw']
			];

			$x = checkLoginDetail($data);

			if ($x) {

				setcookie('pid', $_POST['pid'], time() + (3600*2), "/");				
				echo "true";
			}else{
				echo "error";
			}


		}
		
		
	}

	if (isset($_POST['clsubmit'])) {

		if(empty($_POST['cuid']) || empty($_POST['cpw'])){

			echo "empty";
			//header('location: ../views/login.php?error=null');
		}else{

			$user = [
				'uid'=>$_POST['cuid'],
				'pw'=>$_POST['cpw']
			];

			$status = validateConLogin($user);

			

			if($status){

					setcookie('cons_id', $_POST['cuid'], time() + (3600*10), "/");				    				
					echo "Successfully found.";
					//header('location: ../views/adminHome.php?error=no');

			}
			else{
				//header('location: ../views/login.php?error=invalid');
				echo "Invalid entry. Account does not exist.";
				//header('location: ../adminHome.php?error=no');
			}
		}
		
	}

	if (isset($_POST['attsubmit'])) {
		if (empty($_POST['auid']) || empty($_POST['apw'])) {
			echo "empty";
		}else{

			$user = [
				'uid'=>$_POST['auid'],
				'pw'=>$_POST['apw']
			];

			$status = validateAttLogin($user);

			if($status){

					setcookie('au_id', $_POST['auid'], time() + (3600*10), "/");			    				
					echo "Successfully found.";
					//header('location: ../views/adminHome.php?error=no');

			}
			else{
				//header('location: ../views/login.php?error=invalid');
				echo "Invalid entry. Account does not exist.";
				//header('location: ../adminHome.php?error=no');
			}
		}
	}

	if (isset($_POST['plog'])) {
		if (isset($_COOKIE['pid'])) {
			setcookie('pid', '', time() - (3600*2), "/");
			header("Location:../index.php");
		}
	}

	if (isset($_POST['alog'])) {
		if (isset($_COOKIE['uid'])) {
			setcookie('uid', '', time() - (3600*2), "/");
			header("Location:../index.php");
		}
	}

	if (isset($_POST['clog'])) {
		if (isset($_COOKIE['cons_id'])) {
			setcookie('cons_id', '', time() - (3600*2), "/");
			header("Location:../index.php");
		}
	}

	if (isset($_POST['attlog'])) {
		if (isset($_COOKIE['au_id'])) {
			setcookie('au_id', '', time() - (3600*2), "/");
			header("Location:../index.php");
		}
	}


?>
