<?php

	session_start();
	if(!isset($_COOKIE['pid'])){
		header("location:../../index.php");
	}

?>