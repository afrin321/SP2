<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['canceld'])) {

		//echo "hii";

		$d1 = $_POST['d1'];
		$c= 0;

		$date = date('Y-m-d');
		//echo $date;

		if ($d1>$date) {

			//echo $d1." ".$date;
		
				
				$x = cancelInfo($d1);
		
				//echo $d1." ".implode(" ", $x[0]);
				if ($x) {
					
					for ($i=0; $i <count($x) ; $i++) {
		
						if (($x[$i]['queueStatus']=='Active') && ($x[$i]['queueCurQuantity']<1)) {
							
							$y = cancelForDay($d1);
							echo $y;
							if ($y) {
								
								$z = true;
								$c += 1;
							}
						}else{
		
							$q_id = $x[$i]['queueId'];
							$a = listForCancel($q_id);
		
							// echo $a[0];
							// echo count($a);
		
							if ($a) {
		
								for ($i=0; $i <count($a) ; $i++) {
		
									$p_id = $a[$i]['pid'];
									$s_id = $x[$i]['queueSlotId'];
		
									$t = time();
									//echo(date("d-m-Y",$t));
		
									$tempDate = date("d-m-Y",$t);
									$Date1 = date('Y-m-d',strtotime($tempDate));
		
		
									$d2 = [
										'p'=>$p_id,
										's'=>$s_id
		
									];
		
									$title = "Cancelled Appointment";
		
									$m = "Dear valued Client, your Appointment on ".$x[$i]['queueDate']." has been cancelled. Your payment has been refunded.	
										- Hospital Management";
		
									$d3 = [
										'p'=>$p_id,
										'm'=>$m,
										't'=>$Date1,
										'title'=>$title
									];
		
		
									$w = updateAccPay($d2);
									$v = notificationOne($d3);
									$u = updateAppQueueOnCancel($q_id);
									$y2 = cancelForDay($d1);
		
										// echo $w." ";
										// echo $y2." ";
										// echo $u;
		
									if ($w && $y2 && $u) {
									
										$z = true;
										$c += 1;
									}
		
								}
		
								
							}else{
								$y2 = cancelForDay($d1);
		
								if ($y2) {
									$z = true;
									$c += 1;
								}
		
							}
		
		
		
						}
		
					}
				}

				if ($z) {
					if ($c == 1) {
						echo $c." Appointment cancelled successfully.";
					}else{
						echo $c." Appointments cancelled successfully.";
					}			
				}else{
					echo "error";
				}





		}else{
			echo "error day over";
		}

	}
	//needs rechekcing


	if (isset($_POST['cancels'])) {
		
		$f = getInfoForSlotAppTwo($_POST['s1']);

		//if there are active slots for this con...
		if (count($f)>0) {
		
		$d = listcancelslot($_POST['s1']);
		//why is consID given for $f and slotId for $d??

		if ($d) {

			if (count($d)>0) {		
				
			for ($i=0; $i <count($d) ; $i++) {

				$qid = $d[$i]['queueId'];
				$b = listForCancel($qid);

				if ($b) {
					
				for ($i=0; $i < count($b); $i++) { 
					$pid = $b[$i]['pid'];
					$sid = $d[$i]['queueSlotId'];

					$t = time();
					//echo(date("d-m-Y",$t));
		
					$tempDate = date("d-m-Y",$t);
					$Date1 = date('Y-m-d',strtotime($tempDate));
		
		
					$d2 = [
						'p'=>$pid,
						's'=>$sid
		
					];

					$title = "Cancelled Appointment";
		
					$m = "Dear valued Client, your Appointment on ".$d[$i]['queueDate']." has been cancelled. Your payment has been refunded.	
										- Hospital Management";


					$d3 = [
							'p'=>$pid,
							'm'=>$m,
							't'=>$Date1,
							'title'=>$title
					];
		
		
					$w = updateAccPay($d2);
					$v = notificationOne($d3);
					$u = updateAppQueueOnCancel($sid);
					$y2 = cancelforSlot($_POST['s1']);
					$y3 = deleteSlot($_POST['s1']);


					if ($w && $v && $u && $y2 && $y3) {
						//true echoed for one slot						
						//echo "true";
						$c1++;
					}else{
						//echo $w." ".$v." ".$u." ".$y2." ".$y3;
						$cn1++;
					}


				}
			}




			}
		}else{
			
			$y3 = deleteSlot($_POST['s1']);
			if ($y3) {
				echo "true";
			}else{
				echo "error1";
			}

		}
	}else{

		//echo "nothing in queueinitialize";
		// here all the slots have to be deactivated

		for ($i=0; $i < count($f) ; $i++) { 
			$p = deleteSlot($f[$i]['slot_id']);
		}
		//not considering all counts seperately
		if ($p) {
			echo "true";
		}

	}

		// "update queueinitialize set queueStatus='Cancelled' where queueSlotId='{$data}' and queueDate>CURRENT_DATE";

		# code...
}else{
	echo "error2";
	}
}


?>