<?php

	session_start();
	if(!isset($_COOKIE['uid'])){
		header("location:./../../index.php");
	}

?>