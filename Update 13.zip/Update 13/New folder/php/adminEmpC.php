<?php

    session_start();
	require_once('../service/userService.php');

	if (isset($_POST['addemp'])) {
		
		if (empty($_POST['fn']) || empty($_POST['ln']) || empty($_POST['dob']) || empty($_POST['q']) || empty($_POST['pn']) || empty($_POST['em']) || empty($_POST['g'])) {
			
			echo 'empty';
		}else{

			$data = [
				'fn'=>$_POST['fn'],
				'ln'=>$_POST['ln'],
				'dob'=>$_POST['dob'],
				'q'=>$_POST['q'],
				'pn'=>$_POST['pn'],
				'em'=>$_POST['em'],
				'g'=>$_POST['g']
			];

			$x = addAttendant($data);

			if ($x) {
				echo $x;
			}else{
				echo "operation failed";
			}
			

		}
	}

	if (isset($_POST['emplist'])) {
		
		$y = attList();
		if ($y) {
			echo "<table>";
			echo "<tr><th>Id</th><th>Name</th><th>Phone No.</th><th>DOB</th><th>Email</th><th>Add to Slot</th><th>View Slots</th></tr>";
			for ($i=0; $i <count($y) ; $i++){
				echo "<tr>";
				echo "<td>";
				echo $y[$i]['att_id'];
				echo "</td>";
				echo "<td>";
				if ($y[$i]['att_gen']=='Female') {
					echo "Miss. ".ucfirst($y[$i]['att_fn'])." ".ucfirst($y[$i]['att_ln']);
				}elseif($y[$i]['att_gen']=='Male') {
					echo "Mr. ".ucfirst($y[$i]['att_fn'])." ".ucfirst($y[$i]['att_ln']);
				}else{
					echo "Mr./Miss. ".ucfirst($y[$i]['att_fn'])." ".ucfirst($y[$i]['att_ln']);
				}		
				$name = ucfirst($y[$i]['att_fn'])." ".ucfirst($y[$i]['att_ln']);
				echo "</td>";
				echo "<td>";
				echo $y[$i]['att_pno'];
				echo "</td>";
				echo "<td>";
				echo $y[$i]['att_dob'];
				echo "</td>";
				echo "<td>";
				echo $y[$i]['att_em'];
				echo "</td>";
				echo "<td>";
				echo "<input type=\"button\" value=\"Add Slot\" onclick=\"addSlot(".$y[$i]['att_id'].",'".$name."')\">";
				echo "</td>";
				echo "<td><input type=\"button\" value=\"View All Slots\" onclick=\"viewSlot(".$y[$i]['att_id'].",'".$name."')\"></td>";
				echo "</tr>";

			}
			echo "</table>";
		}else{
			echo "Error";
		}
	}

	if (isset($_POST['searchlist'])) {
		$data = $_POST['n'];
		$z = searchList($data);

		

		if ($z) {

			echo "<table>";
			echo "<tr><th>Id</th><th>Name</th><th>Phone No.</th><th>DOB</th><th>Email</th><th>Add to Slot</th><th>View Slots</th></tr>";
			while ($row = mysqli_fetch_assoc($z)) {

				echo "<tr>";
				echo "<td>";
				echo $row['att_id'];
				echo "</td>";
				echo "<td>";
				if ($row['att_gen']=='Female') {
					echo "Miss. ".ucfirst($row['att_fn'])." ".ucfirst($row['att_ln']);
				}elseif($row['att_gen']=='Male') {
					echo "Mr. ".ucfirst($row['att_fn'])." ".ucfirst($row['att_ln']);
				}else{
					echo "Mr./Miss. ".ucfirst($row['att_fn'])." ".ucfirst($row['att_ln']);
				}	

				$name = ucfirst($row['att_fn'])." ".ucfirst($row['att_ln']);

				echo "</td>";
				echo "<td>";
				echo $row['att_pno'];
				echo "</td>";
				echo "<td>";
				echo $row['att_dob'];
				echo "</td>";
				echo "<td>";
				echo $row['att_em'];
				echo "</td>";
				echo "<td>";
				echo "<input type=\"button\" value=\"Add Slot\" onclick=\"addSlot(".$row['att_id'].",'".$name."')\">";
				echo "</td>";
				echo "<td><input type=\"button\" value=\"View All Slots\" onclick=\"viewSlot(".$row['att_id'].",'".$name."')\"></td>";
				echo "</tr>";

		}
			echo "</table>";		

		}else{
			echo "error";
		}
	}

	if (isset($_POST['addslot'])) {
		
		$aid = $_POST['a'];
		echo "<br><br>";
		echo "<label>Search Slot:  </label><input type=\"text\" placeholder=\"Slot Day/ID/Consultant Name\" onkeyup=\"slotInfo()\" id=\"slot_search\">";
		echo "<br><br>";
		//echo "<div id=\"div_4\"></div>";
	}

	if (isset($_POST['slotinfo'])) {

		$data = $_POST['sid'];
		
		$w = slotInfoSearch($data);

		if ($w) {

			echo "<table>";
			echo "<tr><th>Slot Id</th><th>Slot Day</th><th>Start Time</th><th>End Time</th><th>Consultant Name</th><th>Location</th></tr>";

			while ($row = mysqli_fetch_assoc($w)) {

				echo "<tr>";
				echo "</td>";
				echo "<td>";
				echo $row['slot_id'];
				echo "</td>";
				echo "<td>";
				echo ucfirst($row['slot_day']);
				echo "</td>";
				echo "<td>";
				echo date("g:i a", strtotime($row['slot_start_time']));
				echo "</td>";
				echo "<td>";
				echo date("g:i a", strtotime($row['slot_end_time']));
				echo "</td>";

				echo "<td>";
				echo "Dr.  ".ucfirst(conName($row['slot_consId']));
				echo "</td>";
				echo "<td>";
				echo $row['slot_location'];
				echo "</td>";
				echo "<td>";
				echo "<input type=\"button\" onclick=\"addToSlot(".$row['slot_id'].")\" value=\"Add to slot\">";
				
				echo "</td>";
				echo "</tr>";
			}

			echo "</table>";

			//echo "<br><br><label id=\"s_1\"></label>";
			
		}else{
			echo "error";
		}

	}

	if (isset($_POST['attslot'])) {

			//echo "hi";
			
			$aid =  $_POST['aid'];
			$sid = $_POST['sid'];

			$data = [
				'a'=>$aid,
				's'=>$sid
			];

			$v = addAttInfo($data);
			if ($v) {
				echo "Added Successfully";
			}else{
				echo "Error";
			}
		}

	if (isset($_POST['viewslotlist'])) {
		//echo "hii";
		$attid = $_POST['attid'];

		$u = viewAttSlotInfo($attid);
		if ($u) {
			echo "<table>";
			echo "<tr><th>Slot Id</th><th>Slot Day</th><th>Start Time</th><th>Endtime</th><th>Consultant Name</th><th>Remove</th></tr>";

			for ($i=0; $i <count($u) ; $i++){

				echo "<tr>";
				echo "<td>";
				echo $u[$i]['slot_id'];
				echo "</td>";
				echo "<td>";
				echo ucfirst($u[$i]['slot_day']);
				echo "</td>";
				echo "<td>";
				echo  date("g:i a", strtotime($u[$i]['slot_start_time']));
				echo "</td>";
				echo "<td>";
				echo  date("g:i a", strtotime($u[$i]['slot_end_time']));
				echo "</td>";
				echo "<td>";
				echo "Dr.  ".ucfirst(conName($u[$i]['slot_consId']));
				echo "</td>";
				echo "<td>";
				echo "<input type=\"button\" value=\"Remove from Slot\" onclick=\"deleteFromSlot(".$u[$i]['slot_id'].",".$u[$i]['att_id'].")\">";
				echo "</tr>";



			}

			echo "</table>";

		}else{
			echo "error";
		}
	}

	if (isset($_POST['savep'])) {
		
		$data = [
			'id'=>$_POST['auid'],
			'pw'=>$_POST['pw']
		];

		$t =  updatePw($data);

		if ($t) {
			echo "success";
		}else{
			echo "fail";
		}
	}

	if (isset($_POST['remove_a'])) {
		$data = [
			'sid'=>$_POST['slid'],
			'atid'=>$_POST['attid']
		];

		$s = deleteAtt($data);

		if ($s) {
			echo "Removed from slot successfully.";
		}else{
			echo "Some error occured. Try again later.";
		}
	}

?>