<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['allq'])) {

		//echo "in allq";
		//echo $_COOKIE['qidforatt'];

		if(isset($_COOKIE['qidforatt'])){

			$y = $_COOKIE['qidforatt'];
			//echo $y;
			//setcookie("qidforatt", "", time()-600, "/");

		if ($y) {
			
			$x = getQueueAppByIdCon($y);
			$z = existInArrival($y);

			if($z){

				$v = viewArrivalList($y);

			}else{

				$w = insertIntoArrivalList($y);
				if ($w) {
					$v = viewArrivalList($y);
				}
				

				//if ($w) {
				//	echo "added";
				//}
			}
			
			//echo $v;

			//echo $y;
			if ($x) {
				$p=slotinfoAtt($x['0']['queueSlotId']);
			}
			
		if ($x && $v) {

				echo "<div>";
				

				echo "</div>";
				if ($v['doctor_arrival_stat']!='Arrived' && (date("g:i a", strtotime(time()))>date("g:i a", strtotime($p['slot_start_time'])))) {
					//$to_time = date("g:i a", strtotime(time()));
					//$from_time = date("g:i a", strtotime($p['slot_start_time']));
					//echo round(abs($to_time - $from_time) / 60,2). " minute";
					//$lstat = round(abs($to_time - $from_time) / 60,2). " minute";
					$lstat = "Late";
				}else{
					//$to_time = date("g:i a", strtotime(time()));
					//$from_time = date("g:i a", strtotime($p['slot_start_time']));
					//$lstat = round(abs($to_time - $from_time) / 60,2). " minute";
					$lstat = '';
				}

				echo "<div>";
				echo "<fieldset>";
				echo 	"<table>
											<tr>
												<td><b>Doctor's Status: </b></td>
												<td>".$v['doctor_arrival_stat']."</td>
												
												<td>Slot: </td>
												<td></td>
											</tr>
											<tr>
												<td>Late Status: </td>
												<td>".$lstat."</td>
												<td>Currently in Session: ".$v['cur_in_queue']."</td>
												<td></td>
											</tr>
											<tr>
												<td><label>Late possibility: </label></td>
												<td>".$v['late_possibility']."</td>
												<td>Next in Session: ".$v['next_in_queue']."</td>
												<td></td>
											</tr>
										</table>";
				echo 	"<input type=\"button\" value=\"Update\" onclick=\"updateList(".$y.")\"><label id=\"res2\"></label>";
				echo "</fieldset>";
				echo "<div>";
				echo "<br><br>";

			for ($i=0; $i <count($x) ; $i++){
				$o = getPatientInfo($x[$i]['pid']);

				if ($o['p_gender']=='male') {
					$cred = 'Mr. ';
				}elseif($o['p_gender']=='female'){
					$cred = 'Miss./Mrs. ';
				}else{
					$cred = "Mr./Miss. ";
				}

				//echo var_dump($x[$i]['pArrival']);
				if ($x[$i]['pArrival'] == "00:00:00.000000" ) {
					$a_stat = "Default";
					$c_stat = $x[$i]['pApStatus'];
				}else{
					$a_stat = "Arrived";//."  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
					$c_stat = "Waiting";
				}

				if($a_stat == "Arrived" && $x[$i]['pApStatus'] == "Default"){
					$c_name = "queue_div";
				}elseif($x[$i]['pApStatus'] == "Next in Queue"){
					$c_name = "next_queue_div";
				}elseif($x[$i]['pApStatus'] == "Default" && $a_stat = "Default"){
					$c_name = "unarrived";
				}else{
					$c_name = "queue_div";
				}



				echo "<div class=\"".$c_name."\">";
				//echo "<fieldset>";
								
				echo "<br><br>";				
				echo "Queue Position: ".$x[$i]['pQueue'];
				echo "<br><br>";
				echo "Name: ".$cred." ".ucfirst($o['p_firstName'])." ".ucfirst($o['p_lastName']);
				echo "<br><br>";
				echo "Arrival Status: ".$a_stat;
				if ($a_stat=="Arrived") {
					echo "  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
				}
				echo "<br><br>";
				echo "Current Status: ".$x[$i]['pApStatus'];
				echo "<br><br>";
				
				echo "<br>";
				if ($a_stat == "Default") {
					echo "<input type=\"button\" value=\"Arrived\" onclick=\"arrivedUp(".$x[$i]['pid'].",".$x[$i]['appId'].")\">";
					echo "<label id=\"arrival_stat\"></label>";
					//echo "<br><br>";
				}elseif ($a_stat == "Arrived") {
					echo "<input type=\"button\" value=\"Next in Queue\" onclick=\"updateNext(".$x[$i]['pQueue'].",".$v['qid'].")\">";	//updating using qid	
					echo "<label id=\"up_next\"></label>";		
					echo "<br>";

					//echo "<input type=\"button\" value=\"Move to last\">";				
					//echo "<br><br>";
				}
				//echo "<input type=\"button\" value=\"Arrived\" onclick=\"arrivedUp(".$x[$i]['pid'].",".$x[$i]['appId'].")\">";
				//echo "<label id=\"arrival_stat\"></label>";
				//echo "<br><br>";
				//echo "<input type=\"button\" value=\"Move to last\">";				
				echo "<br>";
				//echo "</fieldset>";
				echo "</div>";

				echo "</div>";
				echo "<br><br>";
			}
			
		}else{
			echo "Appointment info not found. This may be because queue is empty.";
			if (empty($x)) {
				//echo "x";
			}
			if (empty($v)) {
				//echo "v";
			}
		}
		}else{
			echo "qid not set";
		}

	}else{
		echo "Please select appointment from home or schedule.";
	}
	}

	if (isset($_POST['upd'])) {

		if (empty($_POST['q'])||empty($_POST['s'])||empty($_POST['l'])) {
			echo "empty";
		}

		$data = [
			'q'=>$_POST['q'],
			's'=>$_POST['s'],
			'l'=>$_POST['l']
		];
		
		$m = updateArrivalList($data);

		if ($m) {
			echo "Updated succesfully";
		}else{
			echo "Some error in system";
		}
	}

	if (isset($_POST['arrived'])) {

		$data = [
			'pid'=>$_POST['p'],
			'appid'=>$_POST['a']
		];
		
		$w = updateArrivalAppqueue($data);

		if ($w) {
			echo "";
		}else{
			echo "false";
		}
	}

	if (isset($_POST['upnext'])) {

		$data = [
			'pq'=>$_POST['p'],
			'qid'=>$_POST['q']
		];
		
		$u = updateDocArrival($data);

		$t = updateAppQueueNext($data);

		if ($u && $t) {
			echo "true";
		}else{
			echo "false";
		}
	}

?>