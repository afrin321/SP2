<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['allq'])) {

		if(isset($_COOKIE['qidforcon'])){

			$y = $_COOKIE['qidforcon'];
			//echo $y;
			//setcookie("qidforcon", "", time()-600, "/");

		
		
		

		if ($y) {
			
			$x = getQueueAppByIdCon($y);
			$z = existInArrival($y);

			if($z){

				$v = viewArrivalList($y);

			}else{

				$w = insertIntoArrivalList($y);
				if ($w) {
					$v = viewArrivalList($y);
				}
				

				//if ($w) {
				//	echo "added";
				//}
			}

			//echo $y;

			//count($x);

		if ($x && $v) {

				echo "<div>";
				

				echo "</div>";

				echo "<div>";
				echo "<fieldset>";
				echo 	"<table>
											<tr>
												<td><b>Doctor's Status: ".$v['doctor_arrival_stat']."</b></td>
												<td><select id=\"dstat\">
													<option value=\"Arrived\">Arrived</option>
													<option value=\"Will be late\">Will be late</option>
													<option value=\"Almost there\">Almost there</option>
													<option value=\"Default\">Default</option>
												</select>
												</td>
												<td>Slot: </td>
												<td></td>
											</tr>
											<tr>
												<td>Late Status: </td>
												<td></td>
												<td>Currently in Session: ".$v['cur_in_queue']."</td>
												<td></td>
											</tr>
											<tr>
												<td><label>Late possibility: </label></td>
												<td><input type=\"text\" placeholder=\"5 minutes\" id=\"lp\"></td>
												<td>Next in Session: ".$v['next_in_queue']."</td>
												<td></td>
											</tr>
										</table>";
				echo 	"<input type=\"button\" value=\"Update\" onclick=\"updateList(".$y.")\"><label id=\"res2\"></label>";
				echo "</fieldset>";
				echo "<div>";
				echo "<br><br>";

			for ($i=0; $i <count($x) ; $i++){

				$o = getPatientInfo($x[$i]['pid']);

				if ($o['p_gender']=='male') {
					$cred = 'Mr. ';
				}elseif($o['p_gender']=='female'){
					$cred = 'Miss./Mrs. ';
				}else{
					$cred = "Mr./Miss. ";
				}

				//echo var_dump($x[$i]['pArrival']);
				if ($x[$i]['pArrival'] == "00:00:00.000000" ) {
					$a_stat = "Default";
					$c_stat = $x[$i]['pApStatus'];
				}else{
					$a_stat = "Arrived";//."  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
					$c_stat = "Waiting";

					
				}

				if($a_stat == "Arrived" && $x[$i]['pApStatus'] == "Default"){
					$c_name = "queue_div";
				}elseif($x[$i]['pApStatus'] == "Next in Queue" || $x[$i]['pApStatus'] == "Calling to join session"){
					$c_name = "next_queue_div";
				}elseif($x[$i]['pApStatus'] == "Default" && $a_stat = "Default"){
					$c_name = "unarrived";
				}else{
					$c_name = "queue_div";
				}

				echo "<div class=\"".$c_name."\">";
				//echo "<fieldset>";
								
				echo "<br><br>";				
				echo "Queue Position: ".$x[$i]['pQueue'];
				echo "<br><br>";
				echo "Name: ".$cred." ".ucfirst($o['p_firstName'])." ".ucfirst($o['p_lastName']);
				echo "<br><br>";
				echo "Arrival Status: ".$a_stat;
				if ($a_stat=="Arrived") {
					echo "  "."<i><img src=\"check.png\" width=\"18\" height=\"18\"></i>";
				}
				echo "<br><br>";
				echo "Current Status: ".$x[$i]['pApStatus'];
				echo "<br><br>";
				
				echo "<br>";
				if (($a_stat=='Arrived'||$a_stat=='Waiting')&&($x[$i]['pApStatus']=='Next in Queue')) {
					echo "<input type=\"button\" value=\"Call to Join\" onclick=\"callP(".$x[$i]['pQueue'].",".$x[$i]['appId'].")\">";
					//echo "<label> Calling <b>Serial ".$x[$i]['pQueue']."</b> to join Appointment</label>";
				}elseif (($a_stat=='Arrived'||$a_stat=='Waiting')&&($x[$i]['pApStatus']=='Calling to join session')) {
					echo "<input type=\"button\" value=\"Joined\" onclick=\"callP(".$x[$i]['pQueue'].",".$x[$i]['appId'].")\">";
					echo "   ";
					echo "<input type=\"button\" value=\"Cancel\" onclick=\"callP(".$x[$i]['pQueue'].",".$x[$i]['appId'].")\">";
					//echo "<br> <label id=\"after_call\"></label>";
				}
				if ($c_stat=='Currently in Session') {
					echo "<br><br>";
					echo "<input type=\"button\" value=\"Mark Completed\">";

				}
				//echo "<input type=\"button\" value=\"Call to Join\" onclick=\"arrivedUp(".$x[$i]['pid'].",".$x[$i]['appId'].")\">";
				//echo "<label id=\"arrival_stat\"></label>";
								
				echo "<br><br>";
				//echo "</fieldset>";
				echo "</div>";

				echo "</div>";
				echo "<br><br>";



				
				/*echo "<fieldset>";

				
				echo "<br><br>";
				echo "Queue Position: ".$x[$i]['pQueue'];
				echo "<br><br>";
				echo "Arrival Status: ".$x[$i]['pApStatus'];
				echo "<br><br>";
				//echo 
				echo "</fieldset>";
				echo "</div>";
				echo "<br><br>";*/
			}
			
		}else{
			echo "Appointment info not found. This may be because queue is empty";
		}
		}else{
			echo "qid not set";
		}

	}else{
		echo "Please select specific appointment from Home or Appointments section.";
	}
	}

	if (isset($_POST['upd'])) {

		if (empty($_POST['q'])||empty($_POST['s'])||empty($_POST['l'])) {
			echo "empty";
		}

		$data = [
			'q'=>$_POST['q'],
			's'=>$_POST['s'],
			'l'=>$_POST['l']
		];
		
		$m = updateArrivalList($data);

		if ($m) {
			echo "Updated succesfully";
		}else{
			echo "Some error in system";
		}
	}

	if (isset($_POST['calltojoin'])) {

		$data = [
			'qid'=>$_POST['appid'],
			'pq'=>$_POST['pid']
		];

		$v = updatepApStatus($data);

		if ($v) {
			echo "yes";
		}else{
			echo "no";
		}



	}

?>