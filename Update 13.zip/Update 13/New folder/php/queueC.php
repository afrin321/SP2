<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['getq'])) {
		
		$p = getAppForQueue($_COOKIE['pid']);

		//echo "<table>";

		if ($p) {
			
			for ($i=0; $i <count($p) ; $i++) { 

				if ($p[$i]['queueDate']>=date("Y-m-d",time())) {

					$q = getAllSlotInfo($p[$i]['queueSlotId']);

					if ($q) {

						$r = getInfoForSlot($q['slot_consId']);
						

					}

					$date1=date_create($p[$i]['queueDate']);
					$date2=date_create(date("Y-m-d",time()));
					$diff=date_diff($date2,$date1);
					//echo $diff->format("%a days");

					
					echo "<fieldset>";
					if($diff->format("%a")>0){
						if ($diff->format("%a")==1) {
							echo "<label align=\"right\"><i>";
							echo $diff->format("%a day remaining");
							echo "</i></label>";
						}else{
							echo "<label align=\"right\"><i>";
							echo $diff->format("%a days remaining");
							echo "</i></label>";
						}
					}else{
							echo "<label><i><span style=\"color:red\">Few hours remaining</span></i></label>";
					}

					echo "<br>";
					echo "Dr. ".ucfirst($r['consName']);
					echo "<br><br>";
					$date = strtotime($p[$i]['queueDate']);
					$date = date('l', $date);
					echo $date.", ";
					
					//echo $p[$i]['queueDay'];
					//echo "<br><br>";
					
					echo $p[$i]['queueDate'];
					echo "<br><br>";
					
					echo "<a href=\"#\" onclick=\"openQueueInfo(".$p[$i]['appId'].")\">Open</a>";
					echo "<br><br>";

					echo "</fieldset>";
					echo "<br><br>";


					
				}
		}

		//echo "</table>";

		}else{
			echo "error";
		}
	}

	if (isset($_POST['queue_list'])) {
		
		$x = getQueueAppById($_POST['queue_list']);

		$yy = $_POST['queue_list'];

		$z = existInArrival($yy);

			if($z){

				$v = viewArrivalList($yy);

			}else{

				$w = insertIntoArrivalList($yy);

				if ($w) {
					$v = viewArrivalList($yy);
				}
				//if ($w) {
				//	echo "added";
				//}
			}

		if ($x && $v) {

				echo "<div>";
				

				echo "</div>";

				echo "<div>";
				echo "<fieldset>";
				echo 	"<table>
											<tr>
												<td><b>Doctor's Status: ".$v['doctor_arrival_stat']."</b></td>
												<td></td>
												<td>Slot: </td>
												<td></td>
											</tr>
											<tr>
												<td>Late Status: </td>
												<td></td>
												<td>Currently in Session: ".$v['cur_in_queue']."</td>
												<td></td>
											</tr>
											<tr>
												<td><label>Late possibility: ".$v['late_possibility']."</label></td>
												<td></td>
												<td>Next in Session: ".$v['next_in_queue']."</td>
												<td></td>
											</tr>
										</table>";
				echo "</fieldset>";
				echo "<div>";
				echo "<br><br>";

			for ($i=0; $i <count($x) ; $i++){



				
				echo "<fieldset>";

				if ($x[$i]['pid']==$_COOKIE['pid']) {
					echo "<b><span style=\"color:red\">Your Position</span></b>";
					echo "<hr>";
					//echo "hii";

				}
				echo "<br><br>";
				echo "Queue Position: ".$x[$i]['pQueue'];
				echo "<br><br>";
				echo "Arrival Status: ".$x[$i]['pApStatus'];
				echo "<br><br>";
				//echo 
				echo "</fieldset>";
				echo "</div>";
				echo "<br><br>";
			}
			
		}
	}

	

	

	

	


?>