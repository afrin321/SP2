<?php

    session_start();

	require_once('../service/userService.php');

	if(isset($_POST['getlog'])){

		//echo "hi";

		$p = $_COOKIE['pid'];
		//echo $p;

		$x = getAllLog($p);
		//$y = 

		if ($x) {
			
			//$t = time();
			//echo(date("d-m-Y",$t));

			//$tempDate = date("d-m-Y",$t);
			//echo "    ";
			//$t2 = date('l', strtotime($tempDate));

			//$Date1 = $tempDate;

			//$t = time();
			//echo $t;

					//echo(date("d-m-Y",$t));

					//$t = strtotime($x[0]['queueDate']);

					//$tempDate = date("d-m-Y",$t);
					//echo "    ";
					//echo $x[0]['queueDate'];
					//echo var_dump($x[0]['queueDate']);

					//$t2 = date('l', strtotime($tempDate));
					//$Date1 = $tempDate;

				for ($i=0; $i < count($x); $i++) { 	
					$t = strtotime($x[$i]['queueDate']);

					$tempDate = date("d-m-Y",$t);
					$Date1 = $tempDate;


					

					if (isset($month1)) {
						if ($month1!=date("F", strtotime($Date1))) {

							$month1 = date("F", strtotime($Date1));
							$year1 = date("o", strtotime($Date1));
					        echo "<h3>".$month1." ".$year1."</h3>";				

						}
					}else{

						$month1 = date("F", strtotime($Date1));
					    $year1 = date("o", strtotime($Date1));
					    echo "<h3>".$month1." ".$year1."</h3>";

					}

					$date = date_create($x[$i]['queueDate']);

					$res = conNameForLog($x[$i]['queueSlotId']);
					$res2 = getAllSlotInfo($x[$i]['queueSlotId']);

					echo "<br>";
					echo "<table><tr class=\"logs\">";
					echo "<td class=\"logs\">".date_format($date, 'l, M d Y')."</td>";
					echo "<td class=\"logs\">"."Dr. ".$res['consName']."</td>";
					echo "<td class=\"logs\">".date("g:i ", strtotime($res2['slot_start_time']))." - ".date("g:i a", strtotime($res2['slot_end_time']))."</td>";
					echo "<td class=\"logs\">".$x[$i]['pFee']."</td>";
					echo "<td class=\"logs\">".$x[$i]['pApStatus']."</td>";
					//echo "<td><a href=\"#\">Open Queue</a>"." | "."<a href=\"#\">Cancel or Reschedule</a>"."</td>";
					echo "</tr></table>";



				//echo $x[$i]['pApStatus'];
				echo "<br>";





				}
		}else{
			echo "not found";
		}
	}

?>