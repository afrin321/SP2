<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['check_p'])) {

		if (isset($_COOKIE['app'])) {
			
		$x = getQueueInfo($_COOKIE['app']);

		if ($x) {

			$y = getAllSlotInfo($x['queueSlotId']);

			if ($x['queueCurQuantity']+1>$y['slot_maxAllowed']) {
				echo "This slot is already full.<br>";
				echo "Please select another date.";

			}else{
			
			echo "<fieldset>";
			echo "<br><br>";
			echo "<label>Date:</label>";
			echo "   ";
			echo date('d-m-Y',strtotime($x['queueDate']));
			echo "<br><br>";
			echo "<label>Consultant:</label>";
			echo "   ";
			echo "Dr. ".ucfirst(getConName($y['slot_id']));
			echo "<br><br>";
			echo "<label>Queue position:  </label>";
			echo "   ";
			echo $x['queueCurQuantity']+1;
			echo "<br><br>";
			echo "<label>Fee:  </label>";
			echo "   ";
			echo "Tk.  ".$y['slot_fee'].".00";
			echo "<br><br>";
			echo "Confirm Appointment?";
			echo "   ";
			echo "<input type=\"button\" value=\"Confirm\" onclick=\"confirm()\">"."  "."<input type=\"button\" value=\"Cancel\" onclick=\"cancelApp()\">";
			echo "<br><br>";
			echo "</fieldset>";
		}

		}
		}elseif(isset($_COOKIE['pay'])){

			if ($_COOKIE['pay']=="success") {
				echo "success";
			}else{
				echo "pay";
			}

			//echo "pay";

		}else{

			if (isset($_COOKIE['paystat'])) { 
				# code...

				/*
			

			$data = [
			'ap_id'=>$_COOKIE['app2'],
			'q'=>$_COOKIE['q'],
			'pid'=>$_COOKIE['pid']
		];

		if (($_COOKIE['q']==0) || ($_COOKIE['q']<0)) {
			$s=true;
		}else{
			$s = updateQuanOnCancel($data);
		}

		//$s = updateQuanOnCancel($data);
		if ($s) {
			$t = removeFromQueue($data);
			if ($t) {
				$r = updateAppQueueIndex($data);
				if ($r) {*/

					    setcookie("app2", "", time() - (60*10), '/');
						//setcookie("app", "", time() - (60*2), '/');
						//setcookie("pay", "true", time()+(60*2), '/');
						setcookie("q", "", time()-(60*10), '/');
						setcookie("paystat", "", time()-(60*10), '/');

					//setcookie("pay", "", time()-(60*2), '/');
					//setcookie("q", "", time()-(60*2), '/');

					//echo "false";
			/*	}
			}
		}*/



	}

			echo "false";
		}



		
		//echo "true";
	}else{
		echo "  ";
	}


	if (isset($_POST['cancelp'])) {
		
		if (isset($_COOKIE['app'])) {
			setcookie("app", "", time() - (60*2), '/');
			echo "true";
		}
	}





	if (isset($_POST['conf'])) {

		if (isset($_COOKIE['app'])) {
			
		$h = $_COOKIE['app'];
		$j = getQueueInfo($_COOKIE['app']);

		if ($j) {
			$k = getAllSlotInfo($j['queueSlotId']);

			$curQuan = $j['queueCurQuantity']+1;

			if ($curQuan>=$k['slot_maxAllowed']) {
				echo "error";
			}else{
				//$id = $_COOKIE['pid'];
				$data1 = [
					'q'=>$curQuan,
					'i'=>$h
				];


				//$m = updateCurQuan($data1);

				//if ($m) {

					$id = $_COOKIE['pid'];

					$data2 = [
						'qid'=>$h,
						'pid'=>$id,
						'q'=>$curQuan
					];

					//$l = addToAppQueue($data2);

					$l = addToWaitQueue($data2);

					if ($l) {
						setcookie("app2", $h, time() + (60*10), '/');
						setcookie("app", "", time() - (60*2), '/');
						setcookie("pay", "true", time()+(60*2), '/');
						setcookie("q", $curQuan, time()+(60*10), '/');
						setcookie("paystat", "true", time()+(60*10), '/');
						setcookie("wid", $l, time()+(60*10), '/');

						echo "success";
					}

				//}

				//updateCurQuan($curQuan, $h);
			}
		}

		

		



	    }else{

	    	echo "session timeout";
	    }



	}  


	if (isset($_POST['pay'])) {

		if (isset($_COOKIE['app2'])) {
			
		$h = $_COOKIE['app2'];
		$j = getQueueInfo($_COOKIE['app2']);

		if ($j) {
			$k = getAllSlotInfo($j['queueSlotId']);

			$curQuan = $j['queueCurQuantity']+1;

			if ($curQuan>=$k['slot_maxAllowed']) {
				echo "error";
			}else{
				//$id = $_COOKIE['pid'];
				removeFromWaitQueue($_COOKIE['wid']);


				$data1 = [
					'q'=>$curQuan,
					'i'=>$h
				];


				$m = updateCurQuan($data1);

				if ($m) {

					$id = $_COOKIE['pid'];

					$data2 = [
						'qid'=>$h,
						'pid'=>$id,
						'q'=>$curQuan
					];

					$l = addToAppQueue($data2);
					

					/*$l = addToWaitQueue($data2);

					if ($l) {
						setcookie("app2", $h, time() + (60*10), '/');
						setcookie("app", "", time() - (60*2), '/');
						setcookie("pay", "true", time()+(60*2), '/');
						setcookie("q", $curQuan, time()+(60*10), '/');
						setcookie("paystat", "true", time()+(60*10), '/');
						
						echo "success";
					}*/

				//}

				//updateCurQuan($curQuan, $h);
			}
		}

		

		



	    }else{

	    	echo "session timeout";
	    }

		$stat = "payed";

		$data = [
			'ap_id'=>$_COOKIE['app2'],
			'pid'=>$_COOKIE['pid']
		];

		$n = updateAppQueuePayment($data);

		if ($n) {
			setcookie("paystat", "", time()-(60*10), '/');
			setcookie("pay", "success", time()+(60*2), '/');

			


			
			//$stat="true;"
			echo "success";
		}else{
			echo "error";
		}
		

	}
}

	if (isset($_POST['cancelpay'])) {

		$stat = "cancelled";

		$p = removeFromWaitQueue($_COOKIE['wid']);

		if ($p) {
			setcookie("paystat", "", time()-(60*10), '/');

			setcookie("pay", "", time()-(60*2), '/');
			setcookie("q", "", time()-(60*2), '/');

			
			echo "success";
		}else{
			echo "false";
		}


		/*

		$data = [
			'ap_id'=>$_COOKIE['app2'],
			'q'=>$_COOKIE['q'],
			'pid'=>$_COOKIE['pid']
		];

		if (($_COOKIE['q']==0) || ($_COOKIE['q']<0)) {
			$s=true;
		}else{
			$s = updateQuanOnCancel($data);
		}

		//$s = updateQuanOnCancel($data);
		if ($s) {
			$t = removeFromQueue($data);
			if ($t) {
				$r = updateAppQueueIndex($data);
				if ($r) {

					setcookie("paystat", "", time()-(60*10), '/');

					setcookie("pay", "", time()-(60*2), '/');
					setcookie("q", "", time()-(60*2), '/');

					echo "false";
				}
			}
		}*/


		

	}



	if (isset($_POST['waitlist'])) {

		//echo "hii";

		$pid = $_COOKIE['pid'];
		


		$x1 = getWaitQueue($pid);

		if ($x1) {

			//echo $x1;
			echo "<div style=\"overflow-x:auto\">";

		echo "<table id=\"t1\">";
		echo "<tr><th>Date</th><th>Date</th><th>Spots remaining</th><th>Current Queue</th><th>Payment Status</th></tr>";
			
			for ($i=0; $i <count($x1) ; $i++) { 

				if (($x1[$i]['queueDate']>=date("Y-m-d",time()))&&($x1[$i]['queueCurQuantity']<$x1[$i]['queueMax'])) {

					//&&($x1[$i]['queueCurQuantity']<$x1[$i]['queueMax'])
					
			echo "<tr><td";
			echo " value=\"";

			$rem = $x1[$i]['queueMax'] - $x1[$i]['queueCurQuantity'];

			echo $x1[$i]['queueID'];
			echo "\" id=\"getid\">";
			echo $x1[$i]['app_id'];
			echo "</td><td>".$x1[$i]['queueDate']."</td>";
			echo "</td><td>".$rem."</td>";
			
			echo "</td><td>".$x1[$i]['queueCurQuantity']."</td>";
			echo "</td><td>"."<b>Unpaid</b> - "."<a href=\"#\" onclick=\"payLate(".$x1[$i]['queueID'].",".$x1[$i]['app_id'].")\">Pay Now</a>"." | "."<a href=\"#\" onclick=\"cancelWait(".$x1[$i]['queueID'].")\">Cancel</a>"."</td>";
			//echo "<td>".$x1[$i]['queueCurQuantity']."</td>";
			echo "</tr>";
			echo "<br><br>";
		}
		}

		echo "</table>";
		echo "</div>";
		
		}else{
			echo "error";
		}
	}

	if (isset($_POST['ap_w'])) {

		if (isset($_POST['apid']) && isset($_POST['wd'])) {
			$h = $_POST['apid'];
		    $l4 = $_POST['wd'];


		setcookie("app2", $h, time() + (60*10), '/');
		//setcookie("app", "", time() - (60*2), '/');
		setcookie("pay", "true", time()+(60*2), '/');
		//setcookie("late", $l4, time()+(60*10), '/');
		setcookie("paystat", "true", time()+(60*10), '/');
		setcookie("wid", $l4, time()+(60*10), '/');

		
		}
		else{
			echo "error";
		}
		

	}

	if (isset($_POST['wcancel'])) {
		
		$d = removeFromWaitQueue($_POST['wcancel']);

		if ($d) {
			echo "yes";
		}else{
			echo "no";
		}
	}






?>