<?php

    require_once('../../php/sessionC.php');

?>


<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body onload="getNumber()">
	
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="patientHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="patientAppointment.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="patientQueue.php" class="menu">Queue Information</a>
		</li>
		<li class="menu">
			<a href="patientLogs.php" class="menu">Appointment Log</a>
		</li>
		<li class="menu">
			<a href="patientPayment.php" class="menu">Payment</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search </a>  
		</li>
	</ul>

	<div>
		<br>
		<br>
		<div class="Notify" id="n1">

			<span class="notify3" id="n5"></span>
			<label>Notifications</label><label class="open1"><input type="button" name="" value="Open" onclick="viewNotification()"></label>

			<div id="n2">
				
			</div>
			
		</div>
		<div id="sound_n">
			
		</div>


		
	</div>

	<script type="text/javascript">

		//document.getElementById('n2').style.display = "none";
		//document.getElementById('n5').style.display='none';

		

		function viewNotification() {
			
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/patientHomeC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('viewn='+'true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					//document.getElementById('n5').style.display = 'none';

					if (this.responseText=="<br><br>error") {

						document.getElementById('n2').style.display = "hidden";

						document.getElementById('n2').innerHTML = "<br>No notifications at the moment.";

					}else{

						document.getElementById('n2').style.display = "hidden";

						document.getElementById('n2').innerHTML = this.responseText;

					}

				}
			}
		}

		function getNumber(){

			//document.getElementById('n5').style.display='none';

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/patientHomeC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('getn='+'true');

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					var res = this.responseText;
					//document.getElementById('n5').innerHTML = res;
					if (res=='zero') {

						document.getElementById('n5').style.display='none';
					}else{
						document.getElementById('n5').innerHTML = res;
						document.getElementById('n5').style.display ='hidden';
					}


				}
			}
		}

		
		
	</script>

	


</body>
</html>