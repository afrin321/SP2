<?php

    require_once('../../php/sessionC.php');

?>

<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body onload="showLogs()">
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="patientHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="patientAppointment.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="patientQueue.php" class="menu">Queue Information</a>
		</li>
		<li class="menu">
			<a href="patientLogs.php" class="menu">Appointment Log</a>
		</li>
		<li class="menu">
			<a href="patientPayment.php" class="menu">Payment</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search </a>  
		</li>
	</ul>

	<div>
		
	</div>

	<div id="res2">

		

	</div>

	<script type="text/javascript">

		

		function showLogs(){

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/patientLogC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('getlog=true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res2').innerHTML = this.responseText;
				}
			}
		}

		

		



		


	</script>

	


</body>
</html>