<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
	 <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	 <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="homestyle.css">
</head>
<body>
	<div>




		<ul class="up">
		<li class="up">
			<a href="views/Patient/patientLogin.php" class="up">Log In</a>
		</li>
		<li class="up">
			<a href="views/Patient/patientRegister.php" class="up">Register</a>
		</li>
	</ul>
	<br>
	<br>
	<br>
	<div>
		<ul class="menu">
		<li class="menu">
			<a href="" class="menu"><i class="material-icons">home</i>  Home</a>
		</li>
		<li class="menu">
			<a href="" class="menu">About Us</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Departments</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Consultants</a>
		</li>
		<li class="menu">
			<a href="views/appointment.php" class="menu">Appointment</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Services</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Contact Us</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search		<input type="text" name="" class="menu" placeholder=" Search " height="20px"></a>  
		</li>
	</ul>
		
	</div>		
	</div>
	<div class="sec_d">
		<label class="sec_d"><b> Welcome to ApSys Clinic </b></label>
		<br>
		<br>
		<br>
		<br>
		<p>Lorem</p>
	</div>
	
	

	

	





	
	<br>
	<div class="footer">
		<div>
			<table>
				<tr>
					<td class="footer">
						<img src="">
						
					</td>
					<td class="footer">
						<h2 align="left">Employee Login</h2>
						<hr>
						<br>
						<a href="../New folder/views/login.php">Admin</a><br><br>
						<a href="../New folder/views/Consultant/consLogin.php">Consultant</a><br><br>
						<a href="../New folder/views/Attendant/attLogin.php">Attendee</a><br><br>


					</td>
				</tr>
			</table>
			<div>
				<h4 align="center">Copyright@2021</h4>
			</div>

		</div>
		
	

	

</body>
</html>