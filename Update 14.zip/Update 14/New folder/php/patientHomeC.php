<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['viewn'])) {
		
		$j = $_COOKIE['pid'];

		$x = getNotiForP($j);

		echo "<br><br>";

		if ($x) {
			for ($i=0; $i <count($x) ; $i++) { 

				echo "<div class=\"pnoti2\">";
				if ($x[$i]['openStat']=="unseen") {
					echo "<br>";
					echo "<b>NEW</b>";

				}

				echo "<br>";
				echo "<b>".$x[$i]['title']."</b>";

				//echo $x[$i]['n_date'];
				echo "<br>";
				echo $x[$i]['msg'];
				echo "<br><br>";

				echo "</div>";
				echo "<br>";

				notificationTwo($x[$i]['n_id']);


			}
		}else{
			
			echo "error";
		}
	}

	if (isset($_POST['getn'])) {
		
		$p = $_COOKIE['pid'];
		$y = notificationThree($p);

		if ($y) {
			if ($y['count(*)']>0) {
				echo $y['count(*)'];
			}else{
				echo "zero";
			}
		}else{
			echo "zero";
		}
	}


	

?>