<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['canceld'])) {

		//echo "hii";

		$d1 = $_POST['d1'];
		$c= 0;
		
		$x = cancelInfo($d1);

		if ($x) {
			
			for ($i=0; $i <count($x) ; $i++) {

				if (($x[$i]['queueStatus']=='Active') && ($x[$i]['queueCurQuantity']<1)) {
					
					$y = cancelForDay($d1);
					if ($y) {
						
						$z = true;
						$c += 1;
					}
				}else{

					$q_id = $x[$i]['queueId'];
					$a = listForCancel($q_id);

					if ($a) {

						for ($i=0; $i <count($a) ; $i++) {

							$p_id = $a[$i]['pid'];
							$s_id = $x[$i]['queueSlotId'];

							$t = time();
							//echo(date("d-m-Y",$t));

							$tempDate = date("d-m-Y",$t);
							$Date1 = date('Y-m-d',strtotime($tempDate));


							$d2 = [
								'p'=>$p_id,
								's'=>$s_id

							];

							$title = "Cancelled Appointment";

							$m = "Dear valued Client, your Appointment on ".$x[$i]['queueDate']." has been cancelled due to National Holiday. Your payment has been refunded.	
								- Hospital Management";

							$d3 = [
								'p'=>$p_id,
								'm'=>$m,
								't'=>$Date1,
								'title'=>$title
							];


							$w = updateAccPay($d2);
							$v = notificationOne($d3);
							$u = updateAppQueueOnCancel($q_id);
							$y2 = cancelForDay($d1);

							if ($w && $y2 && $u) {
								$z = true;
								$c += 1;
							}

						}

						
					}



				}

			}
		}

		if ($z) {
			echo $c." appointments cancelled successfully.";
		}else{
			echo "error";
		}
	}


?>