<?php

	session_start();
	if(!isset($_COOKIE['pid'])){
		header("location:../views/Patient/patientLogin.php?error=invalid_request");
	}
	/*else{

		echo $_COOKIE['pid'];
	}*/

?>