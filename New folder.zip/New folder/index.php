<!DOCTYPE html>
<html>
<head>
	<title>Home page</title>
	   	<meta charset="utf-8">
	  	<meta name="viewport" content="width=device-width, initial-scale=1">
	  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
		<link rel="stylesheet" href="homestyle.css">
</head>
<body>
	
	
	




		<ul class="up">
		<li class="up">
			<a href="views/Patient/patientLogin.php" class="up">Log In</a>
		</li>
		<li class="up">
			<a href="views/Patient/patientRegister.php" class="up">Register</a>
		</li>
	</ul>
	<br>
	<br>
	<br>
	<div class="container-fluid">
		<ul class="menu">
		<li class="menu">
			<a href="" class="menu"><i class="material-icons">home</i>  Home</a>
		</li>
		<li class="menu">
			<a href="" class="menu">About Us</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Consultants</a>
		</li>
		<li class="menu">
			<a href="views/appointment.php" class="menu">Appointment</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Services</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Contact Us</a>
		</li>
		
			<input type="text" name="" class="menu" placeholder=" Search " height="20px">
					
	</ul>
		
	</div>		
	


	<div class="sec_d container-fluid">>
		<label class="sec_d"><b> Welcome to ApSys Clinic </b></label>
		<br>
		<br>
		<br>
		<br>
		<p>Lorem</p>
	</div>
	
	

	

	





	
	<br>
	<div class="footer">
		<div>
			<table>
				<tr>
					<td class="footer">
						<img src="">
						
					</td>
					<td class="footer">
						<h2 align="left">Employee Login</h2>
						<hr>
						<br>
						<a href="../New folder/views/login.php">Admin</a><br><br>
						<a href="../New folder/views/Consultant/consLogin.php">Consultant</a><br><br>
						<a href="../New folder/views/Attendant/attLogin.php">Attendee</a><br><br>


					</td>
				</tr>
			</table>
			<div>
				<h4 align="center">Copyright@2021</h4>
			</div>

		</div>
		
	

	

</body>
</html>