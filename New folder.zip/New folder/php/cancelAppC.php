<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['cancelex'])){

		$data = [
			'date'=>$_POST['d'];
			
		];
		
		$x = 
	}
	





?>