<?php

	session_start();

	require_once('../service/userService.php');

	if (isset($_POST['gettoday'])) {
		$data = $_COOKIE['au_id'];
		//echo $data;
		$x = attTodayList($data);
		//echo count($x);

		if ($x) {

			//echo "hi";

			for ($i=0; $i <count($x) ; $i++) { 

				$data = $x[$i]['slot_id'];

				//echo $data;

				$y = attQinfoHome($data);

				//echo count($y);

				if($y){

				echo "<fieldset>";
				echo "Consultant: Dr. ".ucfirst(getConName($x[$i]['slot_consId']));
				echo "<br><br>";
				echo "Time: ".date("g:i a", strtotime($x[$i]['slot_start_time']))." - ".date("g:i a", strtotime($x[$i]['slot_end_time']));
				echo "<br><br>";
				echo "<label>Day: </label>".ucfirst($x[$i]['slot_day']);
				echo "<br><br>";
				echo "Room No.: ".$x[$i]['slot_location'];
				echo "<br><br>";
				echo "Status: ".ucfirst($x[$i]['slot_Status']);
				echo "<br><br>";
				//echo $x[$i]['slot_id'];
				//echo $y['queueId'];
				$j = 0;
				//echo $y[$j]['queueId'];
				echo "<input type=\"button\" name=\"\" value=\"View Queue\" onclick=\"openQ(".$y[$j]['queueId'].")\">";

				echo "</fieldset>";
			
		}else{
			//echo "Appointments not booked for Today's slot yet.";
		}

			}
		}
	}

	if (isset($_POST['setqinfo'])) {

		$id = $_POST['setqinfo'];
		
		setcookie("qidforatt", $id, time()+600, "/");

		echo "true";
			
	}

?>