<?php

    session_start();

	require_once('../service/userService.php');

	if (isset($_POST['canceld'])) {

		//echo "hii";

		$d1 = $_POST['d1'];
		$c= 0;

		$date = date('Y-m-d');
		//echo $date;

		if ($d1>$date) {

			//echo $d1." ".$date;
		
				
				$x = cancelInfo($d1);
		
				//echo $d1." ".implode(" ", $x[0]);
				if ($x) {
					
					for ($i=0; $i <count($x) ; $i++) {
		
						if (($x[$i]['queueStatus']=='Active') && ($x[$i]['queueCurQuantity']<1)) {
							
							$y = cancelForDay($d1);
							echo $y;
							if ($y) {
								
								$z = true;
								$c += 1;
							}
						}else{
		
							$q_id = $x[$i]['queueId'];
							$a = listForCancel($q_id);
		
							// echo $a[0];
							// echo count($a);
		
							if ($a) {
		
								for ($i=0; $i <count($a) ; $i++) {
		
									$p_id = $a[$i]['pid'];
									$s_id = $x[$i]['queueSlotId'];
		
									$t = time();
									//echo(date("d-m-Y",$t));
		
									$tempDate = date("d-m-Y",$t);
									$Date1 = date('Y-m-d',strtotime($tempDate));
		
		
									$d2 = [
										'p'=>$p_id,
										's'=>$s_id
		
									];
		
									$title = "Cancelled Appointment";
		
									$m = "Dear valued Client, your Appointment on ".$x[$i]['queueDate']." has been cancelled due to National Holiday. Your payment has been refunded.	
										- Hospital Management";
		
									$d3 = [
										'p'=>$p_id,
										'm'=>$m,
										't'=>$Date1,
										'title'=>$title
									];
		
		
									$w = updateAccPay($d2);
									$v = notificationOne($d3);
									$u = updateAppQueueOnCancel($q_id);
									$y2 = cancelForDay($d1);
		
										// echo $w." ";
										// echo $y2." ";
										// echo $u;
		
									if ($w && $y2 && $u) {
									
										$z = true;
										$c += 1;
									}
		
								}
		
								
							}else{
								$y2 = cancelForDay($d1);
		
								if ($y2) {
									$z = true;
									$c += 1;
								}
		
							}
		
		
		
						}
		
					}
				}

				if ($z) {
					if ($c == 1) {
						echo $c." Appointment cancelled successfully.";
					}else{
						echo $c." Appointments cancelled successfully.";
					}			
				}else{
					echo "error";
				}





		}else{
			echo "error day over";
		}

	}


?>