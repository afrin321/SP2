<?php

	session_start();

	require_once('../service/userService.php');

	if (isset($_POST['gettoday'])) {

		//echo "hii";
		
		$x = getTodayListforCon($_COOKIE['cons_id']);

		if ($x) {
			
		for ($i=0; $i <count($x) ; $i++) { 
			echo "<fieldset>";
			echo "<label>Day: </label>".ucfirst($x[$i]['slot_day']);
			echo "<br><br>";
			echo "<label>Start time: </label>".date("g:i a", strtotime($x[$i]['slot_start_time']));
			echo "<br><br>";
			echo "<label>End time: </label>".date("g:i a", strtotime($x[$i]['slot_end_time']));
			echo "<br><br>";
			echo "<label>Current queue: </label>".$x[$i]['queueCurQuantity'];
			echo "<br><br>";
			echo "<label>Room No.: </label>".$x[$i]['slot_location'];
			echo "<br><br>";
			echo "<input type=\"button\" name=\"\" value=\"View Queue\" onclick=\"openQ(".$x[$i]['queueId'].")\">";
			echo "</fieldset>";
		}
	}else{
		echo "error";
	}


		
	}

	if (isset($_POST['setqinfo'])) {

		$id = $_POST['setqinfo'];
		
		setcookie("qidforcon", $id, time()+600, "/");

		if (isset($_COOKIE['qidforcon'])) {
			echo "true";
		}else{
			echo "false";
		}
	}




?>