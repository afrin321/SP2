<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="../homestyle.css">
</head>
<body>
	
	<br>
	<br>
		<nav class="navbar navbar-expand-sm bg-light container-fluid">
			<ul class="menu navbar-nav">
				<li class="menu nav-item">
					<a href="adminHome.php" class="menu nav-link">Home</a>
				</li>
				<li class="menu nav-item">
					<a href="adminDept.php" class="menu nav-link">Departments</a>
				</li>
				<li class="menu nav-item">
					<a href="adminConsultants.php" class="menu nav-link">Consultants</a>
				</li>
				<li class="menu nav-item">
					<a href="adminPatient.php" class="menu nav-link">Patient Info</a>
				</li>
				<li class="menu nav-item">
					<a href="conSlot.php" class="menu nav-link">Slots</a>
				</li>
				<li class="menu nav-item">
					<a href="adminEmp.php" class="menu nav-link">Employees</a>
				</li>
				<li class="menu nav-item">
					<a href="" class="menu nav-link">Settings</a>
				</li>
				<li class="menu nav-item">
					<a href="" class="menu nav-link">Search </a>  
				</li>
			</ul>
		</nav>

		






	


</body>
</html>