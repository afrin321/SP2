<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Att home</h1>
<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body onload="getAll()">
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="attHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="conApp.php.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Cancellations</a>
		</li>
		<li class="menu">
			<a href="conQueue.php" class="menu">Queues</a>
		</li>		
		<li class="menu">
			<a href="#" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Search </a>  
		</li>
	</ul>
	<br><br><br><br>
	<h2>Today's Appointments</h2>

	<div id="res1">
		
	</div>
	<p id="stat1"></p>

	<script type="text/javascript">
		function getAll(){
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/attHomeC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('gettoday='+'true');	
		
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=='error') {
						document.getElementById('res1').innerHTML = "No Appointments for this day";
					}else{
						document.getElementById('res1').innerHTML = this.responseText;
					}

					
					
				}
			}
		}

		function openQ(s){

			//document.getElementById('stat1').innerHTML = s;
			

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/attHomeC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('setqinfo='+s);	
		
			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					location.replace("attQueue.php");
					
					
				}
			}

		}
		
	</script>

	


</body>
</html>
</body>
</html>