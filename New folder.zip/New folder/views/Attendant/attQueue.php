<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body onload="loadInitial()">
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="attHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="conApp.php.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Cancellations</a>
		</li>
		<li class="menu">
			<a href="conQueue.php" class="menu">Queues</a>
		</li>		
		<li class="menu">
			<a href="#" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Search </a>  
		</li>
	</ul>
	<br><br><br><br>
	<h2>Today's Appointments</h2>

	<div id="res1">
		
	</div>
	<div id="res3"></div>
	<p id="stat1"></p>

	<script type="text/javascript">
		//var e=1;

		function loadInitial(){
			setInterval(getAll,3000);
		}
		
		function getAll(){
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/attQueueC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('allq='+'true');	
		
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res1').innerHTML = this.responseText;
					
					//console.log(e);
					//e+=1;
					
				}
			}
		}

		function updateList(q){

			var s = document.getElementById('dstat').value;
			var l = document.getElementById('lp').value;
			//document.getElementById('res3').innerHTML = s+" "+l+" ";
			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/conQueueC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('upd='+'true'+'&s='+s+'&l='+l+'&q='+q);	
		
			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res2').innerHTML = this.responseText;
					
				}
			}
		}

		function arrivedUp(p,a){
			var pid = p;
			var appid = a;

			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/attQueueC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('arrived='+'true'+'&a='+appid+'&p='+pid);	
		
			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('arrival_stat').innerHTML = this.responseText;
					
				}
			}


		}

		function updateNext(p,q){

			var pq = p;
			var qid = q;

			var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../../php/attQueueC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('upnext='+'true'+'&q='+qid+'&p='+pq);	
		
			/*xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('up_next').innerHTML = this.responseText;
					
				}
			}*/

		}

		
		
	</script>

	


</body>
</html>