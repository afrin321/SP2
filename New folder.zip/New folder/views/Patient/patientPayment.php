<?php

require_once('../../php/sessionC.php');
//echo $_COOKIE['pid'];

?>


<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<!-- <link rel="stylesheet" href="homestylePayment.css"> -->
	
</head>
<body onload="startActions()">
	<p id="resofw"></p>
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="patientHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="patientAppointment.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="patientQueue.php" class="menu">Queue Information</a>
		</li>
		<li class="menu">
			<a href="patientLogs.php" class="menu">Appointment Log</a>
		</li>
		<li class="menu">
			<a href="patientPayment.php" class="menu">Payment</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search </a>  
		</li>
	</ul>
	<br><br>

	<div class="container-fluid">
			<h3 class="display-5">Payments</h3>
			<hr>
			<br>
		<div id="res" class="container-fluid">
			<fieldset>
				<legend><h3>Current Payment</h3></legend>

				<div>
					
				</div>
			</fieldset>
		</div>
		<div id="res3" class="container-fluid"></div>
		<div class="container-fluid">
			<fieldset>
				<legend>Pending Payment</legend>
				<br>
				<p>Complete payment to book your spot.</p>
				<div id="res2"></div>
				<br>
			</fieldset>
		</div>
		<br>
		<div class="container-fluid">
			Current Balance: Tk.<label id="balance"></label>
		</div>
		
	</div>

	<script type="text/javascript">

		setInterval("startActions()", 5000);
		document.getElementById('res3').style.display = "none";


		document.getElementById('res').style.display = "none";

		function startActions(){
			checkP();
			waitList();
			getBalace();
		}


		
		function checkP(){

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/paymentC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('check_p='+'true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=="false"){

						document.getElementById('res').innerHTML = "";
						document.getElementById('res').style.display = "block";

					}else if(this.responseText=="pay"){

						document.getElementById('res').innerHTML = "<label id=\"topay\"></label><label>Card Details</label><input type=\"text\" id=\"card\">		<label>Amount</label><input type=\"text\" id=\"amnt\"><br><br><input type=\"button\" value=\"Pay\" onclick=\"pay()\">"+"  "+"<input type=\"button\" value=\"Cancel\" onclick=\"cancelPay()\">";
						document.getElementById('res').style.display = "block";

					}else if(this.responseText=="success"){
						document.getElementById('res').innerHTML = "Appointment made successfully.";
						document.getElementById('res').style.display = "block";
					}else{

						document.getElementById('res').innerHTML = this.responseText;
						document.getElementById('res').style.display = "block";
					}

					
				}
			}
		}

		function cancelApp(){

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/paymentC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('cancelp='+'true');

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText) {

						
						document.getElementById('res').innerHTML = "";
						document.getElementById('res').style.display = "none";
						
									
				}
			}
		}
	}

	function confirm(){

		document.getElementById('res').innerHTML = "Processing...";
		document.getElementById('res').style.display = "block";

		var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/paymentC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('conf='+'true');

			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){



										
						//document.getElementById('res').innerHTML = this.responseText;
						document.getElementById('res').style.display = "block";
						
						
									
				}
		}


	}

	function pay(){

		document.getElementById('res').innerHTML = "Processing...";
		document.getElementById('res').style.display = "block";



		var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../../php/paymentC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('pay='+'true');

			xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

										
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText=="success") {

							document.getElementById('res').innerHTML = "Successfully added";
							document.getElementById('res').style.display = "block";
						}else{
							document.getElementById('res').innerHTML = "In progress..";
							document.getElementById('res').style.display = "block";

						}
						//document.getElementById('res').style.display = "block";
						
						
									
				}
		}

	}

	function cancelPay(){

		document.getElementById('res').innerHTML = "Processing...";
		document.getElementById('res').style.display = "block";



		    var xhttp5 = new XMLHttpRequest();
		 	xhttp5.open('POST', '../../php/paymentC.php', true);
			xhttp5.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp5.send('cancelpay='+'true');

			xhttp5.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
									
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText=="success") {
							document.getElementById('res').innerHTML = "Successfully cancelled.";
							document.getElementById('res').style.display = "block";
						}
					
							//document.getElementById('res').style.display = "block";
							//document.getElementById('res').style.display = "block";				
						
									
				}
		}


	}

	function waitList(){

		//document.getElementById('res2').innerHTML = "suppose";
		//document.getElementById('res2').style.display = "block";

		var xhttp6 = new XMLHttpRequest();
		 	xhttp6.open('POST', '../../php/paymentC.php', true);
			xhttp6.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp6.send('waitlist='+'true');

			xhttp6.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
									
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText!="error") {
						
							document.getElementById('res2').innerHTML = this.responseText;
							document.getElementById('res2').style.display = "block";

						}else{

							document.getElementById('res2').innerHTML = "Empty";
							document.getElementById('res2').style.display = "block";

						}
								
							//document.getElementById('res').style.display = "block";
							//document.getElementById('res').style.display = "block";				
										
				}
		}

	}

	function payLate(wid, apid){

		//document.getElementById('res').innerHTML = "Processing...";
		//document.getElementById('res').style.display = "block";

		//var appId = document.getElementById('getid').innerHTML; 
		//var wd = document.getElementById('getid').value; 

		//document.getElementById('getid').innerHTML = appId+"  "+wid;
		//document.getElementById('resofw').style.display = "block";

		



		var xhttp7 = new XMLHttpRequest();
		 	xhttp7.open('POST', '../../php/paymentC.php', true);
			xhttp7.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp7.send('ap_w='+'true'+'&apid='+apid+'&wd='+wid);

			xhttp7.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

										
						//document.getElementById('res').innerHTML = this.responseText;
						if (this.responseText=="success") {

							document.getElementById('res').innerHTML = "Successfully added";
							document.getElementById('res').style.display = "block";
						}else{
							document.getElementById('res').innerHTML = "In progress..";
							document.getElementById('res').style.display = "block";

						}
						//document.getElementById('res').style.display = "block";
						
						
									
				}
		}



	}

	function cancelWait(wd){

		document.getElementById('res').innerHTML = "Cancelling...";

			var xhttp8 = new XMLHttpRequest();
		 	xhttp8.open('POST', '../../php/paymentC.php', true);
			xhttp8.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp8.send('wcancel='+wd);

			xhttp8.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=="yes") {

										
						document.getElementById('res').innerHTML = "Cancelled Successfully.";

					}
						
						//document.getElementById('res').style.display = "block";
						
						
									
				}
		}

	}

	function getBalace(){

		var xhttp9 = new XMLHttpRequest();
		 	xhttp9.open('POST', '../../php/paymentC.php', true);
			xhttp9.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp9.send('accb='+'true');

			xhttp9.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('balance').innerHTML = this.responseText;

				}
			}


	}

	</script>

	

	


</body>
</html>