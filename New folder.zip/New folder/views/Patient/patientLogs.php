<?php

    require_once('../../php/sessionC.php');

?>

<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="../homestyle.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body onload="showLogs()">
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="patientHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="patientAppointment.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="patientQueue.php" class="menu">Queue Information</a>
		</li>
		<li class="menu">
			<a href="patientLogs.php" class="menu">Appointment Log</a>
		</li>
		<li class="menu">
			<a href="patientPayment.php" class="menu">Payment</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search </a>  
		</li>
	</ul>

	<div class="container-fluid">
		<h3 class="display-5">Appointment Logs</h3>
				<hr>
				<br>	
				
		<div id="res2" class="container-fluid">

			

		</div>
	</div>

	<script type="text/javascript">

		

		function showLogs(){

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/patientLogC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('getlog=true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res2').innerHTML = this.responseText;
				}
			}
		}

		function cancelLog(a, p, d, q){
			var x = confirm('Are you sure you want to cancel the Appointment?');
			var app = a;
			var pid = p;
			var dn  = d;
			var q = q;

			

			 if (x == true) {

			 	var xhttp2 = new XMLHttpRequest();
			 	xhttp2.open('POST', '../../php/patientLogC.php', true);
				xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp2.send('cancel=true'+'&app='+app+'&pid='+pid+'&dn='+dn+'&q='+q);

			 	xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText.trim()=='true') {

						document.getElementById('res2').innerHTML = "<div class=\"alert alert-success\"><strong>Success!</strong> Appointment cancelled.</div>";

					}

					
				}
			}
			   
			}

			
		}

		

		



		


	</script>

	


</body>
</html>