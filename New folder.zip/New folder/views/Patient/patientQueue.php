<?php

    require_once('../../php/sessionC.php');
    //echo $_COOKIE['pid'];

?>


<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body onload="getQueues()">
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="patientHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="patientAppointment.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="patientQueue.php" class="menu">Queue Information</a>
		</li>
		<li class="menu">
			<a href="patientLogs.php" class="menu">Appointment Log</a>
		</li>
		<li class="menu">
			<a href="patientPayment.php" class="menu">Payment</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search </a>  
		</li>
	</ul>

	<div>

		<h1>Queue Information</h1>

		<div id="res"></div>
		<div id="res2">
			<a href="#" onclick="backTo()">Back</a>
			<br>
			<br>
			<div id="res3">
				
				
			</div>

		</div>

		
		


		
	</div>

	<script type="text/javascript">

		document.getElementById('res2').style.display = "none";
		var active = false;
		var v;

		

		

		function getQueues(){
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/queueC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('getq='+'true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
								
						document.getElementById('res').innerHTML = this.responseText;
						document.getElementById('res').style.display = "block";			
				}
		}

		}

		

		function openQueueInfo(ap_id){

			console.log('new');
			
			
			document.getElementById('res').style.display = "none";
			document.getElementById('res2').style.display = "block";								

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/queueC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('queue_list='+ap_id);

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){	

						document.getElementById('res3').innerHTML = this.responseText;

						if (active==false) {

							active=true;


							myVar = setInterval(openQueueInfo, 60000*2, ap_id);

						}

												
													
				}
		
		//setInterval(openQueueInfo(ap_id), 60000);
			
		}	

		}


		function backTo(){	

			clearInterval(myVar);
			active = false;
	

			document.getElementById('res2').style.display = "none";
			document.getElementById('res').style.display = "block"			

		}

		

		

		

		



		
		
	</script>

	


</body>
</html>