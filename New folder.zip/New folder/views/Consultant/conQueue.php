<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body onload="loadInitial()">
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="consHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="conApp.php.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Cancellations</a>
		</li>
		<li class="menu">
			<a href="conQueue.php" class="menu">Queues</a>
		</li>		
		<li class="menu">
			<a href="#" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Search </a>  
		</li>
	</ul>
	<br><br><br><br>
	<h2>Today's Appointments</h2>

	<div id="res1">
		
	</div>
	<div id="res3"></div>
	<p id="stat1"></p>

	<script type="text/javascript">
		function loadInitial(){
			setInterval(getAll,3000);
		}

		function getAll(){
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/conQueueC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('allq='+'true');	
		
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res1').innerHTML = this.responseText;
					
				}
			}
		}

		function updateList(q){

			var s = document.getElementById('dstat').value;
			var l = document.getElementById('lp').value;
			//document.getElementById('res3').innerHTML = s+" "+l+" ";
			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/conQueueC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('upd='+'true'+'&s='+s+'&l='+l+'&q='+q);	
		
			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res2').innerHTML = this.responseText;
					
				}
			}
		}

		function callP(p, a, pid){

			var pqid = p;
			var appid = a;
			var pd = pid;

			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/conQueueC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('calltojoin='+'true'+'&pid='+pqid+'&appid='+appid+'&p='+pd);	
		
			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('stat1').innerHTML = this.responseText;
					
				}
			}

		}

		function joinP(p, a, pid){

			var pqid = p;
			var appid = a;
			var pd = pid;

			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../../php/conQueueC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('joined='+'true'+'&pid='+pqid+'&appid='+appid+'&p='+pd);	
		
			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('stat1').innerHTML = this.responseText;
					
				}
			}

		}

		function markP(p, a, pid){

			var pqid = p;
			var appid = a;
			var pd = pid;

			var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../../php/conQueueC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('mark='+'true'+'&pid='+pqid+'&appid='+appid+'&p='+pd);	
		
			xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('stat1').innerHTML = this.responseText;
					
				}
			}

		}

		
		
	</script>

	


</body>
</html>