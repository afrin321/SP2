<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body onload="getUpcoming()">
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="consHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="conApp.php.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="conCancel.php" class="menu">Cancellations</a>
		</li>
		<li class="menu">
			<a href="conQueue.php" class="menu">Queues</a>
		</li>		
		<li class="menu">
			<a href="#" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Search </a>  
		</li>
	</ul>
	<br><br><br><br>
	<div>

		<h2>Upcoming Appointments</h2>
		<hr>
		<br><br>
		<div id="upc"></div>
		<br><br>	
		<label><a href="#">View All</a></label>
	</div>
	<br><br>
	<div>
		<h2>Completed Appointments</h2>
		<hr>
		<br><br>
	</div>

	<script type="text/javascript">	

		function getUpcoming(){

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/conAppC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('upcoming='+'true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('upc').innerHTML= this.responseText;

					

					
				}
			}
		}

		function openQueue(id){

			var s = id;

			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../../php/conAppC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('setqinfo='+id);

			xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if (this.responseText=='true') {
						location.replace("conQueue.php?error=no");
					}
					
				}

					

					
				}
			}

		function cancelQueue(id){

			var s = id;
			var r = confirm("Are you sure you want to cancel this Appointment?");
			  if (r == true) {

			  	var xhttp3 = new XMLHttpRequest();
			 	xhttp3.open('POST', '../../php/conAppC.php', true);
				xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
				xhttp3.send('cancel');

					xhttp3.onreadystatechange = function(){
						if(this.readyState == 4 && this.status == 200){
							
						}
							
					}
			    
			  }

			

		}

		
		
	</script>

	


</body>
</html>