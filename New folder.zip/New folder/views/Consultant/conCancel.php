<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="homestyle.css">
</head>
<body>
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="consHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="conApp.php.php" class="menu">Appointments</a>
		</li>
		<li class="menu">
			<a href="conCancel.php" class="menu">Cancellations</a>
		</li>
		<li class="menu">
			<a href="conQueue.php" class="menu">Queues</a>
		</li>		
		<li class="menu">
			<a href="#" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="#" class="menu">Search </a>  
		</li>
	</ul>
	<br><br><br><br>
	<div>
		Cancelation Date <input type="date" id="d"> <input type="button" onclick="getC()" value="Open">

		<DIV id="upc">
			
		</DIV>



		
	</div>
	<br><br>
	

	<script type="text/javascript">	

		function getC() {

			var d = document.getElementById('d').value;

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../../php/conAppC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('cancelex='+'true'+'&d='+d);

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('upc').innerHTML= this.responseText;

					

					
				}
			}

		}


		
		
	</script>

	


</body>
</html>