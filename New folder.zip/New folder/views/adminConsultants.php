<?php 

?>


<!DOCTYPE html>
<html>
<head>
	<title>Consultants</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="../homestyle.css">
</head>
<body>
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="adminHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="adminDept.php" class="menu">Departments</a>
		</li>
		<li class="menu">
			<a href="adminConsultants.php" class="menu">Consultants</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Patient Info</a>
		</li>
		<li class="menu">
			<a href="conSlot.php" class="menu">Slots</a>
		</li>
		<li class="menu">
			<a href="adminEmp.php" class="menu">Employees</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search </a>  
		</li>
	</ul>

	<div class="container-fluid inner_box">
		<h1 class="display-3">Consultants</h1>
		<hr>
		Select one of the options from below to view details.<br>
		<br>
		<div class="btn-group btn-group-lg">
			<input type="button" name="" value="Add new Account" class="btn btn-primary" onclick="addNew()">
			<input type="button" name="" value="Search" onclick="search()" class="btn btn-primary">
			<input type="button" name="" value="View All" onclick="getAll()" class="btn btn-primary">
			
		</div> 
		<br><br>
		<div class="container-fluid" id="allC">

			<div id="newConsultantAdding" class="container-fluid">

				<div id="div1" class="container-fluid">

					<h3 class="display-5">Add New Consultant Account</h3>
					<hr>
					<br>
					<div class="form-group">
					  <label for="cname">Name:</label>
					  <input type="text" class="form-control" id="cname" placeholder="Full Name">
					</div>
					 <div class="form-group">
						<label for="dlist">Department:</label>
						<select class="form-control" id="dlist">
						    
						</select>
					</div> 
					<div class="form-group">
					  <label for="cphone">Phone Number:</label>
					  <input type="text" class="form-control" id="cphone">
					</div>
					<div class="form-group">
					  <label for="cemail">Email Address:</label>
					  <input type="email" class="form-control" id="cemail">
					</div>
					<div class="form-group">
					  <label for="caddress">Address:</label>
					  <textarea class="form-control" rows="5" id="caddress"></textarea>
					</div> 
					<div class="form-group">
					  <label for="cdob">DOB:</label>
					  <input type="date" class="form-control" id="cdob">
					</div>
					<div class="form-group">
					  <label for="cqual">Qualification:</label>
					  <textarea class="form-control" rows="5" id="cqual"></textarea>
					</div> 
					<div class="form-group">
					  <label for="cexp">Experience:</label>
					  <textarea class="form-control" rows="5" id="cexp"></textarea>
					</div> 
					<div class="form-group">
					  <label for="cavail">Days Available:</label>
					  <input type="text" class="form-control" id="cavail">
					</div>

					<input type="button" name="" value="Add" onclick="add()"  class="btn btn-primary"> 
					<label id="addresult"></label>
					<br>
					<input type="button" name="" value="Next" id="nextbtn1" onclick="next1()" class="btn btn-primary">		

				</div>
				<div id="div2" class="container-fluid">
					<h3 class="display-5">Credentials</h3>
					<hr>
					<br>
					<div class="form-group">
					  <label>Consultant Id:</label>
					  <label id="cid"></label>
					</div>
					<div class="form-group">
					  <label for="passw">Password (Temporary):</label>
					  <input type="password" class="form-control" id="passw" value="12345">
					</div>
					<br>
					<input type="button" name="" value="Next" onclick="next2()" class="btn btn-primary">



				</div>

				<div id="div3">
					<h3 class="display-5">Upload a Picture</h3>
					<hr>
					<br>
				<form method="post" action="../php/adminConsC.php" enctype="multipart/form-data">
					<h4 class="display-5" id="dd"></h4>
					<br>
					<input type="file" name="cphoto" class="form-control-file border">
					<br><br>
					<input type="submit" name="pupload" value="Upload" class="btn btn-primary">

<!-- 					<table>
						<tr>
							<td id="dd">
								<img src="">
							</td>
						</tr>
						<tr>
							<td>
								<input type="file" name="cphoto" class="btn btn-primary">
							</td>
						</tr>
						<tr>
							<td>
								<input type="submit" name="pupload" value="Upload" class="btn btn-primary">
							</td>
						</tr>
					</table> -->
				</form>
				</div>

			</div>


				
		</div>
		<div id="openSearch" class="container-fluid">
			<h3 class="display-5">Search Consultant Account</h3>
			<hr>
			<br>

			<div class="form-group">
			  <label for="sbox">Search:</label>
			  <input type="text" class="form-control" id="sbox" onkeyup="searchC()">
			</div>
			<br>
			<div class="container-fluid" id="res3">
				
			</div>

<!-- 		<table>
			<tr>
				<td>
					Search: <input type="text" name="" id="sbox" onkeyup="searchC()">
				</td>
			</tr>
			<tr>
				<td id="res3">
					
				</td>
			</tr>
		</table> -->
		
	</div>

				<div id="allCons" class="container-fluid">

					
				</div>

				
		</div>
	</div>

		



	




	<div id="accntDets">
		<legend>Account Details</legend>
	</div>

	<script type="text/javascript">
		document.getElementById('allC').style.display = 'block';
		document.getElementById('accntDets').style.display = "none";
		document.getElementById('newConsultantAdding').style.display = "none";
		document.getElementById('nextbtn1').style.display = "none";
		document.getElementById('div3').style.display = 'none';
		document.getElementById('openSearch').style.display = 'none';
		document.getElementById('allCons').style.display = "none";

		function addNew() {
			document.getElementById('openSearch').style.display = 'none';
			document.getElementById('newConsultantAdding').style.display = "none";
			if(document.getElementById('newConsultantAdding').style.display == "none"){
				document.getElementById('newConsultantAdding').style.display = "block";
				document.getElementById('div1').style.display = 'block';
				document.getElementById('div2').style.display = 'none';
				document.getElementById('div3').style.display = 'none';
			    showList();
			}else{
				document.getElementById('newConsultantAdding').style.display = "none";
			}

			var xhttp9 = new XMLHttpRequest();
		 	xhttp9.open('POST', '../php/adminConsC.php', true);
			xhttp9.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp9.send('full_list_d='+'true');

			xhttp9.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('dlist').innerHTML = this.responseText;
				}
			}
		}

		function next1(){
			document.getElementById('div1').style.display = 'none';
			document.getElementById('div3').style.display = 'none';
			document.getElementById('div2').style.display = 'block';

			var xhttp3 = new XMLHttpRequest();
		 	xhttp3.open('POST', '../php/adminConsC.php', true);
			xhttp3.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp3.send('cid='+'true');

			xhttp3.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
					document.getElementById('cid').innerHTML = this.responseText;

					}
					else{
						document.getElementById('cid').innerHTML = 'no';
					}
			}


			//document.getElementById('cid').innerHTML = "";

		}

		function next2(){
			document.getElementById('div2').style.display = 'none';
			document.getElementById('div3').style.display = 'block';

			var pw = document.getElementById('passw').value;
			var id1 = document.getElementById('cid').innerHTML;
			var xhttp6 = new XMLHttpRequest();
		 	xhttp6.open('POST', '../php/adminConsC.php', true);
			xhttp6.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp6.send('initialpass='+pw+'&id1='+id1);


   //       	xhttp6.onreadystatechange = function(){
			// 	if(this.readyState == 4 && this.status == 200){

			// 		document.getElementById('dd').innerHTML = this.responseText;
					
			// 	}
			// }
		}

		function searchC(){

			var cname = document.getElementById('sbox').value;
			var xhttp4 = new XMLHttpRequest();
		 	xhttp4.open('POST', '../php/adminConsC.php', true);
			xhttp4.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp4.send('cname='+cname);


         	xhttp4.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('res3').innerHTML = this.responseText;
					document.getElementById('res3').style.display = 'block';
					
				}
			}
		}

		function add(){
			//console.log('In add');
			var name = document.getElementById('cname').value;
			var dept =document.getElementById('dlist').value;
			var phoneno = document.getElementById('cphone').value;
			var email = document.getElementById('cemail').value;
			var address = document.getElementById('caddress').value;
			var dob = document.getElementById('cdob').value;
			var qualification = document.getElementById('cqual').value;
			var exp = document.getElementById('cexp').value;
			var dayavail = document.getElementById('cavail').value;
			//var photo = document.getElementById('cphoto').value;

			
			var xhttp2 = new XMLHttpRequest();
		 	xhttp2.open('POST', '../php/adminConsC.php', true);
			xhttp2.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp2.send('name='+name+'&dept='+dept+'&phone='+phoneno+'&email='+email+'&address='+address+'&dob='+dob+'&qualification='+qualification+'&exp='+exp+'&dayavail='+dayavail);

			document.getElementById('addresult').innerHTML = name;


         	xhttp2.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					var res2 = this.responseText;

					//document.getElementById('addresult').innerHTML = this.responseText;



					if(res2=='success'){

						document.getElementById('addresult').innerHTML = "Added Successfully";
						document.getElementById('nextbtn1').style.display = "block";

						//document.getElementById('div1').style.display = 'none';
						//document.getElementById('div2').style.display = 'block';
					}else{

						document.getElementById('addresult').innerHTML = 'error';

					}

			       //document.getElementById('addresult').innerHTML = this.responseText;

				}
			}

			//var x = 5;


		}

		function showList(){

			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../php/departmentC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('full_list='+'true');

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					document.getElementById('dlist').innerHTML = "Department: "+ this.responseText;

				}
			}


			


			//document.getElementById('list1').style.display = "block";
		}

		function search(){

			document.getElementById('newConsultantAdding').style.display = "none";
			document.getElementById('allCons').style.display = "none";
			document.getElementById('res3').style.display = 'none';
			document.getElementById('sbox').value = "";

			document.getElementById('openSearch').style.display = 'none';
			if (document.getElementById('openSearch').style.display=='none') {
				document.getElementById('openSearch').style.display = 'block';
			}else{
				document.getElementById('openSearch').style.display = 'none';
			}
		}

		function getAll(){
			document.getElementById('openSearch').style.display = 'none';

			document.getElementById('allCons').style.display = 'none';

			if (document.getElementById('allCons').style.display == "none") {
			document.getElementById('allCons').style.display = "block";

			var xhttp8 = new XMLHttpRequest();
		 	xhttp8.open('POST', '../php/adminConsC.php', true);
			xhttp8.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp8.send('all='+'free');


         	xhttp8.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					$res = this.responseText;

					if ($res!='error 8') {
						document.getElementById('allCons').innerHTML = this.responseText;
					}

					//document.getElementById('allCons').innerHTML = this.responseText;
					
				}
			}
		}else{
			document.getElementById('allCons').style.display = "none";
		}



		}

		

	</script>

	


</body>
</html>