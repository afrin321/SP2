<!DOCTYPE html>
<html>
<head>
	<title>Home</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	<link rel="stylesheet" href="../homestyle.css">
</head>
<body>
	<br>
	<br>
	<ul class="menu">
		<li class="menu">
			<a href="adminHome.php" class="menu">Home</a>
		</li>
		<li class="menu">
			<a href="adminDept.php" class="menu">Departments</a>
		</li>
		<li class="menu">
			<a href="adminConsultants.php" class="menu">Consultants</a>
		</li>
		<li class="menu">
			<a href="adminPatient.php" class="menu">Patient Info</a>
		</li>
		<li class="menu">
			<a href="conSlot.php" class="menu">Slots</a>
		</li>
		<li class="menu">
			<a href="adminEmp.php" class="menu">Employees</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Settings</a>
		</li>
		<li class="menu">
			<a href="" class="menu">Search </a>  
		</li>
	</ul>

	<div class="container-fluid">

		<div class="container-fluid">
			<h3 class="display-5">Cancel Appointment</h3>
			<hr>
			<br>
			<h4>Select date to cancel appointment. Check thoroughly as cancelled appointments cannot be retrieved.</h4>

			<div class="container-fluid" id="r2"></div>
			<br>
			<div class="form-group">
			  <label for="d1">Date:</label>
			  <input type="date" class="form-control" id="d1">
			</div>
			<input type="button" name="" value="Cancel Day" onclick="cancelDay()" class="btn btn-primary">
			<br>
			
			<br>
			
<!-- 			<input type="text" name="" placeholder="Slot Id">   <input type="button" name="" value="Cancel Slot"> <label id="r1"></label>
			<br>
			
			<br>
			<input type="date" name="" id="d1">  <input type="button" name="" value="Cancel Day" onclick="cancelDay()">   -->
<!-- 			<label id="r2"></label> -->


			
			

		</div>
		
	</div>

	<script type="text/javascript">
		
		function cancelDay() {

			var d1 = document.getElementById('d1').value;
			var xhttp = new XMLHttpRequest();
		 	xhttp.open('POST', '../php/adminPatientC.php', true);
			xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
			xhttp.send('canceld='+'true'+'&d1='+d1);

			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){

					if ((this.responseText.trim()=='error')||(this.responseText.trim()=='error day over')) {

						document.getElementById('r2').innerHTML = "<div class=\"alert alert-danger\"><strong>Error!</strong> "+"  "+"Appointment not cancelled."+"</div>";


					}else{		
											
						document.getElementById('r2').innerHTML = "<div class=\"alert alert-success\"><strong>Success!</strong> "+"  "+this.responseText+"</div>";
					
					}

				}
			}
		}
	</script>

	


</body>
</html>